<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - PT Yuan Adam</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* HEADER TENTANG KAMI */
        .about-header {
            background: linear-gradient(rgba(10, 25, 47, 0.9), rgba(10, 25, 47, 0.8)), url('assets/img/ttg.jpg');
            background-size: cover;
            background-position: center;
            padding: 100px 5%;
            text-align: center;
            color: white;
        }

        /* BAGIAN PROFIL */
        .profile-section {
            padding: 80px 5%;
            background: white;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 50px;
        }

        .profile-text { flex: 1; min-width: 300px; }
        .profile-text h2 { color: #0a192f; margin-bottom: 20px; font-size: 2rem; }
        .profile-text p { color: #555; line-height: 1.8; margin-bottom: 15px; text-align: justify; }

        .profile-image { flex: 1; min-width: 300px; }
        .profile-image img { 
            width: 100%; 
            border-radius: 10px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.15); 
            border-left: 5px solid #25D366; 
        }

        /* VISI MISI */
        .visimisi-section { background: #f4f7f6; padding: 60px 5%; text-align: center; }
        .visimisi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 40px; }
        .vm-card { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .vm-card h3 { color: #0a192f; margin-bottom: 15px; border-bottom: 2px solid #25D366; display: inline-block; padding-bottom: 5px; }

        /* --- LAYOUT KONTAK & MAPS BARU --- */
        .contact-map-section {
            padding: 80px 5%;
            background: #fff;
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            align-items: flex-start; /* Agar sejajar atas */
        }

        /* KARTU KONTAK (KIRI) */
        .contact-card {
            flex: 1;
            min-width: 320px;
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08); /* Efek bayangan halus */
            border: 1px solid #eee;
        }

        .contact-item {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }

        .icon-box {
            width: 50px;
            height: 50px;
            background: #f0fdf4;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #25D366;
            font-size: 1.2rem;
            flex-shrink: 0;
        }

        .info-box h4 { color: #0a192f; margin-bottom: 5px; font-size: 1.1rem; }
        .info-box p { color: #666; font-size: 0.95rem; line-height: 1.6; }

        /* SOSMED ICONS */
        .social-links { margin-top: 30px; }
        .social-links h4 { color: #0a192f; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }
        .social-links h4 i { color: #ff3b30; } /* Hati merah */
        
        .social-icons { display: flex; gap: 15px; }
        .social-btn {
            width: 45px; height: 45px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            color: white; text-decoration: none;
            transition: 0.3s;
            font-size: 1.2rem;
        }
        .bg-fb { background: #1877F2; }
        .bg-ig { background: #E4405F; }
        .bg-yt { background: #FF0000; }
        .bg-tk { background: #000000; }
        
        .social-btn:hover { transform: translateY(-3px); opacity: 0.9; }

        /* CONTAINER MAPS (KANAN) */
        .map-wrapper {
            flex: 1.5; /* Maps lebih lebar sedikit dari kontak */
            min-width: 320px;
            height: 550px; /* Tinggi disesuaikan dengan isi kontak */
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            position: relative;
        }

        .map-wrapper iframe {
            width: 100%;
            height: 100%;
            border: 0;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit; display:flex; align-items:center;">
                ROOTBLOWER<span>ID</span>
            </a>
        </div>

        <div class="hamburger" onclick="toggleMenu()">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>

        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link">Home</a> 

            <div class="nav-link dropdown-parent">
                Tipe Root Blower <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="brand_anlet.php">ANLET</a>
                    <a href="brand_futsu.php">FUTSU</a>
                    <a href="brand_tsurumi.php">TSURUMI</a>
                </div>
            </div>

            <div class="nav-link dropdown-parent">
                Aplikasi <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="aplikasi_wwtp.php">WWTP / IPAL</a>
                    <a href="aplikasi_tambak.php">Tambak Udang</a>
                    <a href="aplikasi_aerasi.php">Aeration</a>
                    <a href="aplikasi_bioflok.php">Bioflok</a>
                </div>
            </div>

            <a href="harga.php" class="nav-link">Harga</a>
            <a href="about.php" class="nav-link active">About Us</a>
            <a href="blog.php" class="nav-link">Artikel</a>
            <a href="#kontak" class="btn-contact-mobile">Hubungi Kami</a>
        </div>

        <div class="nav-right">
            <a href="#kontak" class="btn-contact">Hubungi Kami</a>
        </div>
    </nav>

    <header class="about-header">
        <h1 style="font-size: 3rem; margin-bottom: 10px;">Tentang PT Yuan Adam</h1>
        <p style="font-size: 1.2rem; color: #64ffda; font-weight: 500;">Partner Terpercaya Solusi Industri & Pengolahan Limbah</p>
    </header>

    <section class="profile-section">
        <div class="profile-text">
            <h2>Siapa Kami?</h2>
            <p>
                Didirikan pada tahun 2026, <strong>PT Yuan Adam</strong> telah berkembang menjadi salah satu distributor terkemuka di Indonesia yang mengkhususkan diri pada penyediaan peralatan industri, khususnya <em>Root Blower</em>, <em>Ring Blower</em>, dan <em>Submersible Pump</em>.
            </p>
            <p>
                Kami memegang keagenan resmi untuk berbagai merek kelas dunia seperti <strong>ANLET (Jepang)</strong>, <strong>FUTSU (Taiwan)</strong>, dan <strong>TSURUMI</strong>. Komitmen kami tidak hanya sekadar menjual produk, tetapi memberikan solusi teknis yang tepat guna (efisiensi energi dan performa maksimal) untuk kebutuhan pabrik, IPAL (Instalasi Pengolahan Air Limbah), dan tambak modern.
            </p>
        </div>
        <div class="profile-image">
            <img src="assets/img/tim.jpg" alt="Kantor PT Yuan Adam">
        </div>
    </section>

    <section class="visimisi-section">
        <div class="visimisi-grid">
            <div class="vm-card">
                <h3>Visi Perusahaan</h3>
                <p>Menjadi distributor peralatan industri nomor satu di Indonesia yang dikenal karena keandalan produk, kecepatan pelayanan, dan dukungan teknis purna jual yang unggul.</p>
            </div>
            <div class="vm-card">
                <h3>Misi Kami</h3>
                <ul style="text-align:left; color:#555; list-style:circle; padding-left:20px;">
                    <li>Menyediakan produk root blower berkualitas tinggi dan original.</li>
                    <li>Memberikan solusi efisiensi energi bagi industri manufaktur dan pengolahan limbah.</li>
                    <li>Membangun hubungan jangka panjang dengan pelanggan melalui layanan servis yang responsif.</li>
                </ul>
            </div>
        </div>
    </section>

    <section class="contact-map-section">
        
        <div class="contact-card">
            
            <div class="contact-item">
                <div class="icon-box"><i class="fas fa-map-marker-alt"></i></div>
                <div class="info-box">
                    <h4>Alamat Kantor</h4>
                    <p>Jl. Industri Raya No. 123,<br>Kawasan Industri, Indonesia 51216</p>
                </div>
            </div>

            <div class="contact-item">
                <div class="icon-box"><i class="fas fa-phone-alt"></i></div>
                <div class="info-box">
                    <h4>Telepon & WhatsApp</h4>
                    <p>+62 812-3456-7890 (Sales)<br>+62 858-4255-6218 (Support)</p>
                </div>
            </div>

            <div class="contact-item">
                <div class="icon-box"><i class="fas fa-envelope"></i></div>
                <div class="info-box">
                    <h4>Email Resmi</h4>
                    <p>admin@rootblower.id<br>sales@yuanadam.com</p>
                </div>
            </div>

            <div class="contact-item">
                <div class="icon-box"><i class="fas fa-clock"></i></div>
                <div class="info-box">
                    <h4>Jam Operasional</h4>
                    <p>Senin - Jumat: 08.00 - 17.00 WIB<br>Sabtu: 08.00 - 14.00 WIB</p>
                </div>
            </div>

            <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

            <div class="social-links">
                <h4><i class="fas fa-heart"></i> Follow Kami:</h4>
                <div class="social-icons">
                    <a href="#" class="social-btn bg-fb"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-btn bg-ig"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="social-btn bg-yt"><i class="fab fa-youtube"></i></a>
                    <a href="#" class="social-btn bg-tk"><i class="fab fa-tiktok"></i></a>
                </div>
            </div>

        </div>

        <div class="map-wrapper">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.985956799071!2d109.7341393!3d-6.8922716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7024bd3921804f%3A0x633532709673295e!2sJl.%20Basuki%20Rahmat%20No.2%2C%20Karanganyar%2C%20Kec.%20Batang%2C%20Kabupaten%20Batang%2C%20Jawa%20Tengah%2051216!5e0!3m2!1sid!2sid!4v1700000000000!5m2!1sid!2sid" 
                allowfullscreen="" 
                loading="lazy">
            </iframe>
        </div>

    </section>

    <footer id="kontak">
        <div class="footer-content">
            
            <div class="footer-section">
                <h3>PT YUAN ADAM</h3>
                <p style="margin-bottom: 25px;">Distributor Root Blower terpercaya sejak 2026. Solusi tepat untuk pengolahan limbah dan aerasi industri.</p>

                <h4 style="color: #64ffda; margin-bottom: 15px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;">Follow Us</h4>
                <div class="social-links">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h3>Office</h3>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Head Office:</strong><br>
                    Jl. Basuki Rahmat No. 2 Batang - Jawa Tengah
                </div>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Semarang Office:</strong><br>
                    Jl. KS Tubun No.23 Ungaran Semarang - Jawa Tengah
                </div>
                <div>
                    <strong style="color: #fff;">Surabaya Office:</strong><br>
                    Ruko Galaxi Bumi Permai Blok J1/23A Jl. Raya Sukosemolo,  Semolowaru Sukolilo - Surabaya
                </div>
            </div>

            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Jl. Industri Raya No. 123, Indonesia</p>
                <p><i class="fas fa-phone"></i> +62 812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> admin@rootblower.id</p>
            </div>

        </div>
        
        <div class="copyright">
            <p>&copy; 2026 PT Yuan Adam. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Script Buka-Tutup Menu Panel
        function toggleMenu() {
            var menu = document.getElementById("navMenu");
            var hamburger = document.querySelector(".hamburger");
            menu.classList.toggle("active");
            hamburger.classList.toggle("active");
        }

        // --- TAMBAHAN BARU: SCRIPT DROPDOWN MOBILE --- //
        
        // Ambil semua elemen yang punya anak dropdown
        var dropdowns = document.querySelectorAll('.dropdown-parent');

        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(e) {
                // Cek apakah layar sedang mode HP (<= 991px)
                if (window.innerWidth <= 991) {
                    
                    // Kalau yang diklik bukan link di dalamnya (biar link anak tetep jalan)
                    if (e.target === this || e.target.tagName === 'I' || e.target.textContent.trim() === this.firstChild.textContent.trim()) {
                        
                        // Toggle class 'active' buat buka/tutup
                        this.classList.toggle('active');
                        
                        // Opsional: Tutup dropdown lain biar gak rame (Accordion effect)
                        dropdowns.forEach(function(other) {
                            if (other !== dropdown) {
                                other.classList.remove('active');
                            }
                        });
                    }
                }
            });
        });
    </script>

</body>
</html>
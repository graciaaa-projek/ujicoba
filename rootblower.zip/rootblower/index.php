<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT Yuan Adam - Distributor Root Blower</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit; display:flex; align-items:center;">
                ROOTBLOWER<span>ID</span>
            </a>
        </div>

        <div class="hamburger" onclick="toggleMenu()">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>

        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link active">Home</a>

            <div class="nav-link dropdown-parent">
                Tipe Root Blower <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="brand_anlet.php">ANLET</a>
                    <a href="brand_futsu.php">FUTSU</a>
                    <a href="brand_tsurumi.php">TSURUMI</a>
                </div>
            </div>

            <div class="nav-link dropdown-parent">
                Aplikasi <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="aplikasi_wwtp.php">WWTP / IPAL</a>
                    <a href="aplikasi_tambak.php">Tambak Udang</a>
                    <a href="aplikasi_aerasi.php">Aeration</a>
                    <a href="aplikasi_bioflok.php">Bioflok</a>
                </div>
            </div>

            <a href="harga.php" class="nav-link">Harga</a>
            <a href="about.php" class="nav-link">About Us</a>
            <a href="blog.php" class="nav-link">Artikel</a>

            <a href="https://wa.me/6289517227484?text=Halo%20Admin,%20saya%20tertarik%20dengan%20produk%20Root%20Blower" target="_blank" class="btn-contact-mobile">
                <i class="fab fa-whatsapp"></i> Hubungi Kami
            </a>
        </div>

        <div class="nav-right">
            <a href="https://wa.me/6289517227484?text=Halo%20Admin,%20saya%20tertarik%20dengan%20produk%20Root%20Blower" target="_blank" class="btn-contact">
                <i class="fab fa-whatsapp"></i> Hubungi Kami
            </a>
        </div>
    </nav>

    <header class="hero">
        <h1>Distributor Root Blower Indonesia Terpercaya Solusi Kebutuhan Industri Anda</h1>
        <p>Sebagai distributor root blower terkemuka di Indonesia, PT Yuan Adam hadir untuk memenuhi kebutuhan industri Anda akan blower berkualitas tinggi dan layanan purna jual root blower yang tak tertandingi. Kami menawarkan solusi terbaik untuk efisiensi dan produktivitas maksimal.</p>
        <a href="#katalog" class="btn-cta">Lihat Katalog</a>
    </header>

    <section class="features">
        <div class="feature-box">
            <i class="fas fa-certificate fa-3x" style="color:#0a192f; margin-bottom:15px;"></i>
            <h3>Produk Original</h3>
            <p>Garansi keaslian produk 100% dari pabrikan terpercaya.</p>
        </div>
        <div class="feature-box">
            <i class="fas fa-tools fa-3x" style="color:#0a192f; margin-bottom:15px;"></i>
            <h3>Layanan Teknisi</h3>
            <p>Dukungan instalasi dan servis berkala oleh tim ahli.</p>
        </div>
        <div class="feature-box">
            <i class="fas fa-shipping-fast fa-3x" style="color:#0a192f; margin-bottom:15px;"></i>
            <h3>Pengiriman Cepat</h3>
            <p>Melayani pengiriman ke seluruh wilayah industri Indonesia.</p>
        </div>
    </section>

    <section class="intro-section">
        <div class="intro-wrapper">
            <div class="intro-image">
                <img src="https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Gudang PT Yuan Adam">
                
                <div class="experience-badge">
                    <span>10+</span>
                    <p>Tahun Pengalaman</p>
                </div>
            </div>

            <div class="intro-content">
                <h4>TENTANG PT YUAN ADAM</h4>
                <h2>Distributor Resmi Root Blower & Aerator Terkemuka</h2>
                <p>
                    PT Yuan Adam adalah penyedia solusi industri terdepan yang berfokus pada distribusi Root Blower dan peralatan aerasi berkualitas tinggi. 
                    Berlokasi strategis di pusat industri, kami telah dipercaya oleh ratusan pabrik, WWTP, dan tambak intensif di seluruh Indonesia sebagai mitra andalan.
                </p>
                <p>
                    Kami memahami bahwa mesin adalah jantung operasional Anda. Oleh karena itu, kami tidak hanya menjual unit, tetapi memberikan <strong>solusi teknis lengkap</strong> mulai dari perhitungan kebutuhan udara, instalasi, hingga layanan purna jual yang responsif.
                </p>
                
                <div class="intro-features">
                    <div class="if-item"><i class="fas fa-check"></i> Stok Ready Gudang</div>
                    <div class="if-item"><i class="fas fa-check"></i> Teknisi Bersertifikat</div>
                    <div class="if-item"><i class="fas fa-check"></i> Sparepart Lengkap</div>
                    <div class="if-item"><i class="fas fa-check"></i> Gratis Konsultasi</div>
                </div>

                <a href="about.php" class="btn-intro">Lihat Profil Kami <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </section>

    <div class="container" id="katalog">
        <div class="section-title">
            <h2>Katalog Produk Terbaru</h2>
            <p style="color:#666; margin-top:10px;">Pilihan terbaik untuk kebutuhan IPAL, Tambak, dan Industri Anda</p>
        </div>
        
        <div class="product-grid">
            <?php
            // Ambil data dari database
            $query = mysqli_query($conn, "SELECT * FROM produk ORDER BY 
                CASE 
                    WHEN nama LIKE '%ANLET%' THEN 1 
                    WHEN nama LIKE '%FUTSU%' THEN 2 
                    WHEN nama LIKE '%TSURUMI%' THEN 3 
                    ELSE 4 
                END ASC, id DESC");
                        
            // Cek apakah ada produk?
            if (mysqli_num_rows($query) > 0) {
                while ($row = mysqli_fetch_assoc($query)) {
            ?>
                <div class="card">
                    <img src="uploads/<?php echo $row['gambar']; ?>" alt="<?php echo $row['nama']; ?>">
                    
                    <div class="card-body">
                        <h3><?php echo $row['nama']; ?></h3>
                        
                        <ul class="product-specs">
                            <?php if(!empty($row['model'])) { ?>
                                <li><strong>Model :</strong> <?php echo $row['model']; ?></li>
                            <?php } ?>
                            
                            <li><strong>Pressure :</strong> <?php echo !empty($row['pressure']) ? $row['pressure'] : '-'; ?></li>
                            <li><strong>Capacity :</strong> <?php echo !empty($row['capacity']) ? $row['capacity'] : '-'; ?></li>
                            <li><strong>Power Motor :</strong> <?php echo !empty($row['power']) ? $row['power'] : '-'; ?></li>
                        </ul>

                        <p class="desc-text" style="font-size: 0.9rem; color: #666; margin-bottom: 20px;">
                            <?php echo substr($row['deskripsi'], 0, 100); ?>
                        </p>
                        
                        <?php
                            $nama_produk_wa = $row['nama'];
                            $model_produk_wa = isset($row['model']) ? $row['model'] : '';
                            $pesan_wa = "Halo Admin, saya tertarik dengan produk *" . $nama_produk_wa . "*";
                            $pesan_wa .= ". Mohon info harga dan spesifikasi lengkapnya.";
                            $pesan_wa_encoded = urlencode($pesan_wa);
                        ?>

                        <a href="https://wa.me/6289517227484?text=<?php echo $pesan_wa_encoded; ?>" target="_blank" class="btn-wa">
                            <i class="fab fa-whatsapp"></i> Pesan via WhatsApp
                        </a>

                        <?php
                            $nama_produk = strtoupper($row['nama']); 
                            
                            $link_detail = "detail_produk.php?id=" . $row['id']; 

                            // KECUALI Trio Macan, arahin ke halaman spesial mereka
                            if (strpos($nama_produk, 'ANLET') !== false) {
                                $link_detail = "brand_anlet.php";
                            } elseif (strpos($nama_produk, 'FUTSU') !== false) {
                                $link_detail = "brand_futsu.php";
                            } elseif (strpos($nama_produk, 'TSURUMI') !== false) {
                                $link_detail = "brand_tsurumi.php";
                            }
                        ?>

                        <a href="<?php echo $link_detail; ?>" class="btn-detail">
                            <i class="fas fa-info-circle"></i> Detail Lengkap
                        </a>
                    </div>
                </div>
            <?php 
                } 
            } else { 
            ?>
                <div class="empty-state">
                    <img src="https://cdn-icons-png.flaticon.com/512/4076/4076432.png" width="100" style="opacity:0.5">
                    <h3>Belum ada produk yang diupload</h3>
                    <p>Silakan login ke halaman admin untuk menambahkan produk.</p>
                </div>
            <?php } ?>
        </div>
    </div>

    <section class="brand-info-section">
        <div class="section-title">
            <h2>Keunggulan Brand Utama Kami</h2>
            <p style="color:#666; margin-top:10px;">Mengapa profesional industri mempercayai merek-merek ini?</p>
        </div>

        <div class="brand-grid">
            <div class="brand-box">
                <h3><i class="fas fa-star" style="color:#f59e0b;"></i> ANLET (Japan)</h3>
                <p>
                    Terkenal dengan <strong>desain 3 lobes yang telah dipatenkan</strong>, blower ANLET menawarkan efisiensi energi yang unggul dan tingkat kebisingan yang sangat rendah. Pilihan tepat bagi Anda yang memprioritaskan kualitas udara stabil dan penghematan biaya operasional jangka panjang.
                </p>
            </div>

            <div class="brand-box">
                <h3><i class="fas fa-cogs" style="color:#64ffda;"></i> FUTSU (Taiwan)</h3>
                <p>
                    Dikenal sebagai solusi ekonomis tanpa mengorbankan kualitas. Produk Futsu menonjol karena ketahanan terhadap kondisi operasional berat dan lingkungan korosif. Sangat populer digunakan dalam aplikasi pengolahan limbah (IPAL) dan tambak udang intensif.
                </p>
            </div>

            <div class="brand-box">
                <h3><i class="fas fa-shield-alt" style="color:#0a192f;"></i> TSURUMI</h3>
                <p>
                    Legenda dalam dunia pompa dan blower. Dikenal karena <strong>daya tahannya yang luar biasa</strong> dan kemudahan perawatan. Blower Tsurumi adalah pilihan paling andal untuk aplikasi industri berat yang memerlukan kinerja stabil terus-menerus tanpa henti.
                </p>
            </div>
        </div>
    </section>

    <section class="latest-blog-section">
        <div class="section-title">
            <h2>Artikel & Berita Terbaru</h2>
            <p style="color:#666; margin-top:10px;">Update informasi seputar industri dan teknis root blower</p>
        </div>

        <div class="home-blog-grid">
            <?php
            // QUERY: Ambil 2 artikel terbaru
            $blog_query = mysqli_query($conn, "SELECT * FROM artikel ORDER BY id DESC LIMIT 2");
            
            if(mysqli_num_rows($blog_query) > 0){
                while($blog = mysqli_fetch_assoc($blog_query)){
            ?>
                <div class="home-blog-card">
                    <img src="uploads/<?php echo $blog['gambar']; ?>" alt="<?php echo $blog['judul']; ?>" class="home-blog-img">
                    
                    <div class="home-blog-content">
                        <div class="hb-date">
                            <i class="far fa-calendar-alt"></i> <?php echo date('d M Y', strtotime($blog['tanggal'])); ?>
                            <span style="margin: 0 5px;">•</span>
                            <span><?php echo $blog['views']; ?> Views</span>
                        </div>

                        <h3><a href="detail_artikel.php?id=<?php echo $blog['id']; ?>"><?php echo $blog['judul']; ?></a></h3>
                        
                        <p style="color:#666; font-size:0.9rem; line-height:1.6; margin-bottom:15px;">
                            <?php echo substr($blog['rangkuman'], 0, 100); ?>
                        </p>

                        <a href="detail_artikel.php?id=<?php echo $blog['id']; ?>" class="hb-readmore">
                            Baca Selengkapnya <i class="fas fa-arrow-right" style="font-size:0.8rem;"></i>
                        </a>
                    </div>
                </div>
            <?php 
                }
            } else {
                echo "<p style='text-align:center; width:100%; grid-column:span 2;'>Belum ada artikel terbaru.</p>";
            }
            ?>
        </div>
    </section>

    <footer id="kontak">
        <div class="footer-content">
            
            <div class="footer-section">
                <h3>PT YUAN ADAM</h3>
                <p style="margin-bottom: 25px;">Distributor Root Blower terpercaya sejak 2026. Solusi tepat untuk pengolahan limbah dan aerasi industri.</p>

                <h4 style="color: #64ffda; margin-bottom: 15px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;">Follow Us</h4>
                <div class="social-links">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h3>Office</h3>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Head Office:</strong><br>
                    Jl. Basuki Rahmat No. 2 Batang - Jawa Tengah
                </div>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Semarang Office:</strong><br>
                    Jl. KS Tubun No.23 Ungaran Semarang - Jawa Tengah
                </div>
                <div>
                    <strong style="color: #fff;">Surabaya Office:</strong><br>
                    Ruko Galaxi Bumi Permai Blok J1/23A Jl. Raya Sukosemolo,  Semolowaru Sukolilo - Surabaya
                </div>
            </div>

            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Jl. Industri Raya No. 123, Indonesia</p>
                <p><i class="fas fa-phone"></i> +62 812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> admin@rootblower.id</p>
            </div>

        </div>
        
        <div class="copyright">
            <p>&copy; 2026 PT Yuan Adam. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Script Buka-Tutup Menu Panel
        function toggleMenu() {
            var menu = document.getElementById("navMenu");
            var hamburger = document.querySelector(".hamburger");
            menu.classList.toggle("active");
            hamburger.classList.toggle("active");
        }

        // --- TAMBAHAN BARU: SCRIPT DROPDOWN MOBILE --- //
        
        // Ambil semua elemen yang punya anak dropdown
        var dropdowns = document.querySelectorAll('.dropdown-parent');

        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(e) {
                // Cek apakah layar sedang mode HP (<= 991px)
                if (window.innerWidth <= 991) {
                    
                    // Kalau yang diklik bukan link di dalamnya (biar link anak tetep jalan)
                    if (e.target === this || e.target.tagName === 'I' || e.target.textContent.trim() === this.firstChild.textContent.trim()) {
                        
                        // Toggle class 'active' buat buka/tutup
                        this.classList.toggle('active');
                        
                        // Opsional: Tutup dropdown lain biar gak rame (Accordion effect)
                        dropdowns.forEach(function(other) {
                            if (other !== dropdown) {
                                other.classList.remove('active');
                            }
                        });
                    }
                }
            });
        });
    </script>

</body>
</html>
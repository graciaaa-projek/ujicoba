<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Harga Root Blower Terbaru 2026 - PT Yuan Adam</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* HEADER HALAMAN HARGA */
        .price-header {
            background: linear-gradient(rgba(10, 25, 47, 0.95), rgba(10, 25, 47, 0.85)), url('assets/img/bg.jpg');
            background-size: cover;
            background-position: center;
            padding: 100px 5%;
            text-align: center;
            color: white;
        }

        .price-info-section {
            padding: 60px 5%;
            background: white;
            text-align: center;
        }
        .price-info-section p { max-width: 800px; margin: 0 auto; color: #555; line-height: 1.8; }

        /* KARTU KATEGORI HARGA */
        .price-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 50px;
            padding: 0 5% 80px;
        }

        .price-card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            overflow: hidden;
            transition: 0.3s;
            border: 1px solid #eee;
            position: relative;
        }

        .price-card:hover { transform: translateY(-10px); box-shadow: 0 15px 40px rgba(0,0,0,0.12); }

        .price-card-header {
            background: #f8fafc;
            padding: 25px;
            text-align: center;
            border-bottom: 1px solid #eee;
        }

        .price-card-header h3 { color: #0a192f; margin-bottom: 5px; }
        .price-card-header span { color: #64ffda; font-weight: 700; font-size: 0.9rem; letter-spacing: 1px; }

        .price-card-body { padding: 30px; text-align: center; }
        .price-card-body ul { list-style: none; margin-bottom: 25px; text-align: left; padding-left: 15px; }
        .price-card-body ul li { margin-bottom: 10px; color: #666; font-size: 0.95rem; }
        .price-card-body ul li i { color: #25D366; margin-right: 10px; }

        .btn-minta-harga {
            display: block;
            background: #0a192f;
            color: white;
            padding: 12px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: 0.3s;
        }
        .btn-minta-harga:hover { background: #112240; }
        
        .btn-wa-price {
            display: block;
            background: #25D366;
            color: white;
            padding: 12px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            margin-top: 10px;
        }
        .btn-wa-price:hover { background: #1ebc57; }

        /* BAGIAN CARA PEMESANAN */
        .order-steps { background: #f0fdf4; padding: 60px 5%; text-align: center; }
        .steps-container { display: flex; flex-wrap: wrap; justify-content: center; gap: 30px; margin-top: 40px; }
        .step-box { flex: 1; min-width: 200px; max-width: 300px; position: relative; }
        .step-number { 
            width: 40px; height: 40px; background: #0a192f; color: white; 
            border-radius: 50%; line-height: 40px; font-weight: bold; margin: 0 auto 15px; 
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit; display:flex; align-items:center;">
                ROOTBLOWER<span>ID</span>
            </a>
        </div>

        <div class="hamburger" onclick="toggleMenu()">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>

        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link">Home</a> 

            <div class="nav-link dropdown-parent">
                Tipe Root Blower <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="brand_anlet.php">ANLET</a>
                    <a href="brand_futsu.php">FUTSU</a>
                    <a href="brand_tsurumi.php">TSURUMI</a>
                </div>
            </div>

            <div class="nav-link dropdown-parent">
                Aplikasi <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="aplikasi_wwtp.php">WWTP / IPAL</a>
                    <a href="aplikasi_tambak.php">Tambak Udang</a>
                    <a href="aplikasi_aerasi.php">Aeration</a>
                    <a href="aplikasi_bioflok.php">Bioflok</a>
                </div>
            </div>

            <a href="harga.php" class="nav-link active">Harga</a>
            <a href="about.php" class="nav-link">About Us</a>
            <a href="blog.php" class="nav-link">Artikel</a>
            <a href="#kontak" class="btn-contact-mobile">Hubungi Kami</a>
        </div>

        <div class="nav-right">
            <a href="#kontak" class="btn-contact">Hubungi Kami</a>
        </div>
    </nav>

    <header class="price-header">
        <h1 style="font-size: 3rem; margin-bottom: 10px;">Penawaran Harga Terbaik</h1>
        <p style="font-size: 1.2rem; color: #64ffda; font-weight: 500;">Dapatkan Diskon Khusus untuk Pembelian Proyek & Industri</p>
    </header>

    <section class="price-info-section">
        <h2 style="color: #0a192f; margin-bottom: 20px;">Mengapa Harga Tidak Ditampilkan?</h2>
        <p>
            Sebagai distributor resmi, harga produk Root Blower kami sangat bergantung pada nilai tukar mata uang asing (USD/JPY) dan spesifikasi teknis yang Anda butuhkan (Motor Power, Accessories, dll). 
            Untuk memastikan Anda mendapatkan harga <strong>termurah dan terupdate</strong>, kami menyarankan untuk meminta penawaran resmi (Quotation) langsung kepada tim sales kami.
        </p>
    </section>

    <div class="price-grid">
        
        <div class="price-card">
            <div class="price-card-header">
                <h3>ANLET Blower</h3>
                <span>JAPAN TECHNOLOGY</span>
            </div>
            <div class="price-card-body">
                <ul>
                    <li><i class="fas fa-check-circle"></i> Garansi Resmi 1 Tahun</li>
                    <li><i class="fas fa-check-circle"></i> Unit Baru (Original)</li>
                    <li><i class="fas fa-check-circle"></i> Include Baseplate & Pulley</li>
                    <li><i class="fas fa-check-circle"></i> Gratis Konsultasi Teknis</li>
                </ul>
                <a href="brand_anlet.php" class="btn-minta-harga">Lihat Spesifikasi</a>
                <a href="https://wa.me/6289517227484?text=Halo%20Admin,%20tolong%20kirimkan%20Price%20List%20terbaru%20untuk%20Root%20Blower%20ANLET." target="_blank" class="btn-wa-price">
                    <i class="fab fa-whatsapp"></i> Minta Price List
                </a>
            </div>
        </div>

        <div class="price-card">
            <div class="price-card-header">
                <h3>FUTSU Blower</h3>
                <span>TAIWAN NO.1</span>
            </div>
            <div class="price-card-body">
                <ul>
                    <li><i class="fas fa-check-circle"></i> Harga Paling Ekonomis</li>
                    <li><i class="fas fa-check-circle"></i> Stok Ready Gudang</li>
                    <li><i class="fas fa-check-circle"></i> Sparepart Terjamin</li>
                    <li><i class="fas fa-check-circle"></i> Cocok untuk Tambak/IPAL</li>
                </ul>
                <a href="brand_futsu.php" class="btn-minta-harga">Lihat Spesifikasi</a>
                <a href="https://wa.me/6289517227484?text=Halo%20Admin,%20tolong%20kirimkan%20Price%20List%20terbaru%20untuk%20Root%20Blower%20FUTSU." target="_blank" class="btn-wa-price">
                    <i class="fab fa-whatsapp"></i> Minta Price List
                </a>
            </div>
        </div>

        <div class="price-card">
            <div class="price-card-header">
                <h3>Service & Parts</h3>
                <span>MAINTENANCE</span>
            </div>
            <div class="price-card-body">
                <ul>
                    <li><i class="fas fa-check-circle"></i> Ganti Oli & Bearing</li>
                    <li><i class="fas fa-check-circle"></i> Overhaul Mesin Blower</li>
                    <li><i class="fas fa-check-circle"></i> Gulung Dinamo Motor</li>
                    <li><i class="fas fa-check-circle"></i> Layanan Kunjungan Teknisi</li>
                </ul>
                <a href="#kontak" class="btn-minta-harga">Lokasi Workshop</a>
                <a href="https://wa.me/6289517227484?text=Halo%20Admin,%20saya%20butuh%20jasa%20service/sparepart%20blower." target="_blank" class="btn-wa-price">
                    <i class="fab fa-whatsapp"></i> Tanya Biaya Service
                </a>
            </div>
        </div>

    </div>

    <section class="order-steps">
        <h2 style="color: #0a192f;">Prosedur Pemesanan Mudah</h2>
        <div class="steps-container">
            <div class="step-box">
                <div class="step-number">1</div>
                <h4>Pilih Produk</h4>
                <p>Tentukan tipe blower atau konsultasikan kebutuhan tekanan (pressure) & debit angin Anda.</p>
            </div>
            <div class="step-box">
                <div class="step-number">2</div>
                <h4>Minta Penawaran</h4>
                <p>Hubungi kami via WhatsApp atau Email untuk mendapatkan Surat Penawaran Harga (SPH) resmi.</p>
            </div>
            <div class="step-box">
                <div class="step-number">3</div>
                <h4>PO & Pembayaran</h4>
                <p>Kirimkan Purchase Order (PO) dan lakukan pembayaran DP/Cash sesuai kesepakatan.</p>
            </div>
            <div class="step-box">
                <div class="step-number">4</div>
                <h4>Pengiriman</h4>
                <p>Barang akan kami kirim ke lokasi proyek Anda dengan aman dan berasuransi.</p>
            </div>
        </div>
    </section>

    <footer id="kontak">
        <div class="footer-content">
            
            <div class="footer-section">
                <h3>PT YUAN ADAM</h3>
                <p style="margin-bottom: 25px;">Distributor Root Blower terpercaya sejak 2026. Solusi tepat untuk pengolahan limbah dan aerasi industri.</p>

                <h4 style="color: #64ffda; margin-bottom: 15px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;">Follow Us</h4>
                <div class="social-links">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h3>Office</h3>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Head Office:</strong><br>
                    Jl. Basuki Rahmat No. 2 Batang - Jawa Tengah
                </div>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Semarang Office:</strong><br>
                    Jl. KS Tubun No.23 Ungaran Semarang - Jawa Tengah
                </div>
                <div>
                    <strong style="color: #fff;">Surabaya Office:</strong><br>
                    Ruko Galaxi Bumi Permai Blok J1/23A Jl. Raya Sukosemolo,  Semolowaru Sukolilo - Surabaya
                </div>
            </div>

            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Jl. Industri Raya No. 123, Indonesia</p>
                <p><i class="fas fa-phone"></i> +62 812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> admin@rootblower.id</p>
            </div>

        </div>
        
        <div class="copyright">
            <p>&copy; 2026 PT Yuan Adam. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Script Buka-Tutup Menu Panel
        function toggleMenu() {
            var menu = document.getElementById("navMenu");
            var hamburger = document.querySelector(".hamburger");
            menu.classList.toggle("active");
            hamburger.classList.toggle("active");
        }

        // --- TAMBAHAN BARU: SCRIPT DROPDOWN MOBILE --- //
        
        // Ambil semua elemen yang punya anak dropdown
        var dropdowns = document.querySelectorAll('.dropdown-parent');

        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(e) {
                // Cek apakah layar sedang mode HP (<= 991px)
                if (window.innerWidth <= 991) {
                    
                    // Kalau yang diklik bukan link di dalamnya (biar link anak tetep jalan)
                    if (e.target === this || e.target.tagName === 'I' || e.target.textContent.trim() === this.firstChild.textContent.trim()) {
                        
                        // Toggle class 'active' buat buka/tutup
                        this.classList.toggle('active');
                        
                        // Opsional: Tutup dropdown lain biar gak rame (Accordion effect)
                        dropdowns.forEach(function(other) {
                            if (other !== dropdown) {
                                other.classList.remove('active');
                            }
                        });
                    }
                }
            });
        });
    </script>

</body>
</html>
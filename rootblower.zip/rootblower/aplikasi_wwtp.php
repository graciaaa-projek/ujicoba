<?php 
include 'db.php'; 
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solusi WWTP & IPAL - PT Yuan Adam</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* HEADER KHUSUS APLIKASI */
        .app-header {
            /* Background air/limbah yang bersih */
            background: linear-gradient(rgba(0, 60, 100, 0.9), rgba(0, 40, 70, 0.8)), url('assets/img/wwtp-bg.jpg');
            background-size: cover;
            background-position: center;
            padding: 120px 5%;
            text-align: center;
            color: white;
        }

        .section-info {
            padding: 60px 5%;
            background: white;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 50px;
        }

        .info-text { flex: 1; min-width: 300px; }
        .info-text h2 { color: #0a192f; margin-bottom: 20px; font-size: 2rem; }
        .info-text p { color: #555; line-height: 1.8; margin-bottom: 15px; }

        .info-image { flex: 1; min-width: 300px; }
        .info-image img { width: 100%; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }

        .key-features {
            background: #f0fdf4; /* Hijau muda segar */
            padding: 60px 5%;
            text-align: center;
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .feature-item {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: 0.3s;
        }
        .feature-item:hover { transform: translateY(-5px); }
        .feature-item i { color: #25D366; margin-bottom: 15px; }
        .feature-item h4 { color: #0a192f; margin-bottom: 10px; }

        /* REKOMENDASI PRODUK (Card Layout) */
        .recommendation-section { padding: 80px 5%; background: #f4f7f6; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit; display:flex; align-items:center;">
                ROOTBLOWER<span>ID</span>
            </a>
        </div>

        <div class="hamburger" onclick="toggleMenu()">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>

        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link">Home</a> 

            <div class="nav-link dropdown-parent">
                Tipe Root Blower <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="brand_anlet.php">ANLET</a>
                    <a href="brand_futsu.php">FUTSU</a>
                    <a href="brand_tsurumi.php">TSURUMI</a>
                </div>
            </div>

            <div class="nav-link dropdown-parent">
                Aplikasi <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="aplikasi_wwtp.php" class="nav-link active">WWTP / IPAL</a>
                    <a href="aplikasi_tambak.php">Tambak Udang</a>
                    <a href="aplikasi_aerasi.php">Aeration</a>
                    <a href="aplikasi_bioflok.php">Bioflok</a>
                </div>
            </div>

            <a href="harga.php" class="nav-link">Harga</a>
            <a href="about.php" class="nav-link">About Us</a>
            <a href="blog.php" class="nav-link">Artikel</a>
            <a href="#kontak" class="btn-contact-mobile">Hubungi Kami</a>
        </div>

        <div class="nav-right">
            <a href="#kontak" class="btn-contact">Hubungi Kami</a>
        </div>
    </nav>

    <header class="app-header">
        <h1 style="font-size: 3rem; margin-bottom: 15px;">Solusi Aerasi WWTP & IPAL</h1>
        <p style="font-size: 1.2rem; color: #a5f3fc; font-weight: 500;">Teknologi Root Blower untuk Pengolahan Limbah yang Efisien</p>
    </header>

    <section class="section-info">
        <div class="info-text">
            <h2>Peran Vital Root Blower dalam IPAL</h2>
            <p>
                Dalam sistem <strong>Instalasi Pengolahan Air Limbah (IPAL)</strong> atau <em>Wastewater Treatment Plant (WWTP)</em>, 
                Root Blower berfungsi sebagai jantung dari proses biologi (Aerasi).
            </p>
            <p>
                Mesin ini bertugas menyuplai oksigen secara terus-menerus ke dalam bak aerasi. 
                Oksigen ini sangat dibutuhkan oleh bakteri pengurai (mikroorganisme) untuk hidup dan berkembang biak, 
                sehingga mereka dapat menguraikan limbah organik secara efektif dan menghilangkan bau tak sedap.
            </p>
            <p>
                Tanpa suplai udara yang stabil dari Root Blower, bakteri akan mati dan proses pengolahan limbah akan gagal.
            </p>
        </div>
        <div class="info-image">
            <img src="assets/img/bg.jpg" alt="Instalasi IPAL">
        </div>
    </section>

    <section class="key-features">
        <h2 style="margin-bottom: 40px; color:#0a192f;">Kriteria Blower Terbaik untuk IPAL</h2>
        <div class="feature-grid">
            <div class="feature-item">
                <i class="fas fa-leaf fa-3x"></i>
                <h4>100% Oil Free Air</h4>
                <p>Udara yang dihasilkan harus bersih dari oli agar tidak mencemari air dan membunuh bakteri pengurai.</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-clock fa-3x"></i>
                <h4>Continuous Duty</h4>
                <p>Sistem IPAL bekerja 24 jam nonstop. Blower harus tahan panas dan stabil untuk pemakaian jangka panjang.</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-tachometer-alt fa-3x"></i>
                <h4>Tekanan Stabil</h4>
                <p>Mampu memberikan tekanan udara yang konstan untuk menembus kedalaman kolam aerasi.</p>
            </div>
        </div>
    </section>

    <section class="recommendation-section">
        <div class="section-title">
            <h2>Rekomendasi Produk untuk IPAL</h2>
            <p style="color:#666; margin-top:10px;">Pilihan Root Blower yang telah teruji di ribuan pabrik di Indonesia</p>
        </div>

        <div class="product-grid">
            <?php
            // Menampilkan semua produk karena pada dasarnya semua root blower bisa untuk IPAL
            // Anda bisa memfilter kalau mau, tapi menampilkan variasi merk lebih bagus untuk user memilih
            $query = mysqli_query($conn, "SELECT * FROM produk ORDER BY 
                CASE 
                    WHEN nama LIKE '%ANLET%' THEN 1 
                    WHEN nama LIKE '%FUTSU%' THEN 2 
                    WHEN nama LIKE '%TSURUMI%' THEN 3 
                    ELSE 4 
                END ASC, id DESC LIMIT 6"); // Batasi 6 produk rekomendasi
                        
            if (mysqli_num_rows($query) > 0) {
                while ($row = mysqli_fetch_assoc($query)) {
            ?>
                <div class="card">
                    <img src="uploads/<?php echo $row['gambar']; ?>" alt="<?php echo $row['nama']; ?>">
                    
                    <div class="card-body">
                        <h3><?php echo $row['nama']; ?></h3>
                        
                        <ul class="product-specs">
                            <li><strong>Pressure :</strong> <?php echo !empty($row['pressure']) ? $row['pressure'] : '-'; ?></li>
                            <li><strong>Capacity :</strong> <?php echo !empty($row['capacity']) ? $row['capacity'] : '-'; ?></li>
                            <li><strong>Power :</strong> <?php echo !empty($row['power']) ? $row['power'] : '-'; ?></li>
                        </ul>

                        <?php
                            $nama_produk_wa = $row['nama'];
                            $pesan_wa = "Halo Admin, saya sedang cari Blower untuk IPAL. Saya tertarik dengan tipe *" . $nama_produk_wa . "* mohon info harganya.";
                        ?>
                        <a href="https://wa.me/6285842556218?text=<?php echo urlencode($pesan_wa); ?>" target="_blank" class="btn-wa">
                            <i class="fab fa-whatsapp"></i> Konsultasi IPAL
                        </a>

                        <?php
                            $nama_produk = strtoupper($row['nama']); 
                            $link_detail = "#"; 

                            if (strpos($nama_produk, 'ANLET') !== false) {
                                $link_detail = "brand_anlet.php";
                            } elseif (strpos($nama_produk, 'FUTSU') !== false) {
                                $link_detail = "brand_futsu.php";
                            } elseif (strpos($nama_produk, 'TSURUMI') !== false) {
                                $link_detail = "brand_tsurumi.php";
                            }
                        ?>
                        <a href="<?php echo $link_detail; ?>" class="btn-detail">
                            <i class="fas fa-file-alt"></i> Lihat Spesifikasi
                        </a>
                    </div>
                </div>
            <?php 
                } 
            } 
            ?>
        </div>
    </section>

    <footer id="kontak">
        <div class="footer-content">
            
            <div class="footer-section">
                <h3>PT YUAN ADAM</h3>
                <p style="margin-bottom: 25px;">Distributor Root Blower terpercaya sejak 2026. Solusi tepat untuk pengolahan limbah dan aerasi industri.</p>

                <h4 style="color: #64ffda; margin-bottom: 15px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;">Follow Us</h4>
                <div class="social-links">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h3>Office</h3>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Head Office:</strong><br>
                    Jl. Basuki Rahmat No. 2 Batang - Jawa Tengah
                </div>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Semarang Office:</strong><br>
                    Jl. KS Tubun No.23 Ungaran Semarang - Jawa Tengah
                </div>
                <div>
                    <strong style="color: #fff;">Surabaya Office:</strong><br>
                    Ruko Galaxi Bumi Permai Blok J1/23A Jl. Raya Sukosemolo,  Semolowaru Sukolilo - Surabaya
                </div>
            </div>

            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Jl. Industri Raya No. 123, Indonesia</p>
                <p><i class="fas fa-phone"></i> +62 812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> admin@rootblower.id</p>
            </div>

        </div>
        
        <div class="copyright">
            <p>&copy; 2026 PT Yuan Adam. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Script Buka-Tutup Menu Panel
        function toggleMenu() {
            var menu = document.getElementById("navMenu");
            var hamburger = document.querySelector(".hamburger");
            menu.classList.toggle("active");
            hamburger.classList.toggle("active");
        }

        // --- TAMBAHAN BARU: SCRIPT DROPDOWN MOBILE --- //
        
        // Ambil semua elemen yang punya anak dropdown
        var dropdowns = document.querySelectorAll('.dropdown-parent');

        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(e) {
                // Cek apakah layar sedang mode HP (<= 991px)
                if (window.innerWidth <= 991) {
                    
                    // Kalau yang diklik bukan link di dalamnya (biar link anak tetep jalan)
                    if (e.target === this || e.target.tagName === 'I' || e.target.textContent.trim() === this.firstChild.textContent.trim()) {
                        
                        // Toggle class 'active' buat buka/tutup
                        this.classList.toggle('active');
                        
                        // Opsional: Tutup dropdown lain biar gak rame (Accordion effect)
                        dropdowns.forEach(function(other) {
                            if (other !== dropdown) {
                                other.classList.remove('active');
                            }
                        });
                    }
                }
            });
        });
    </script>

</body>
</html>
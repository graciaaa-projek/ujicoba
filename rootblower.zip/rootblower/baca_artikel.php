<?php 
include 'db.php'; 

// 1. Tangkap ID dari URL
$id = mysqli_real_escape_string($conn, $_GET['id']);

// 2. Update View Counter (Menambah jumlah pembaca setiap kali dibuka)
mysqli_query($conn, "UPDATE artikel SET views = views + 1 WHERE id = '$id'");

// 3. Ambil Data Artikel Utama
$query = mysqli_query($conn, "SELECT * FROM artikel WHERE id = '$id'");
$d = mysqli_fetch_assoc($query);

// Jika artikel tidak ditemukan, kembalikan ke halaman index
if (!$d) {
    header("Location: artikel.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $d['judul']; ?> - Blog PT Yuan Adam</title>
    
    <meta property="og:title" content="<?php echo $d['judul']; ?>">
    <meta property="og:description" content="<?php echo $d['rangkuman']; ?>">
    <meta property="og:image" content="http://localhost/rootblower/uploads/<?php echo $d['gambar']; ?>">
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        /* CSS KHUSUS HALAMAN BACA */
        body { background-color: #f4f7f6; }

        .read-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 5%;
            display: grid;
            grid-template-columns: 2.5fr 1fr; /* Kiri Lebar, Kanan Sempit */
            gap: 40px;
        }

        /* --- BAGIAN KIRI (KONTEN ARTIKEL) --- */
        .article-content {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .breadcrumb-nav {
            font-size: 0.9rem;
            color: #888;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }
        .breadcrumb-nav a { text-decoration: none; color: #888; transition: 0.3s; }
        .breadcrumb-nav a:hover { color: #526af3; }
        .breadcrumb-nav i { font-size: 0.7rem; margin: 0 8px; color: #ccc; }
        .breadcrumb-nav span { color: #0a192f; font-weight: 600; }

        .cat-badge {
            background: #e0f2fe;
            color: #0284c7;
            padding: 5px 12px;
            border-radius: 4px;
            font-weight: 700;
            font-size: 0.85rem;
            display: inline-block;
            margin-bottom: 15px;
            text-transform: uppercase;
        }

        .article-header h1 {
            font-size: 2rem;
            color: #0a192f;
            line-height: 1.3;
            margin-bottom: 15px;
        }

        .article-meta {
            display: flex;
            align-items: center;
            gap: 20px;
            color: #888;
            font-size: 0.9rem;
            margin-bottom: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
        }
        .article-meta i { color: #64ffda; margin-right: 5px; }

        .main-image {
            width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 10px;
        }
        
        .img-caption {
            text-align: center;
            color: #888;
            font-size: 0.85rem;
            margin-bottom: 30px;
            font-style: italic;
        }

        .article-text {
            color: #444;
            line-height: 1.8;
            font-size: 1.05rem;
            text-align: justify;
        }
        .article-text p { margin-bottom: 20px; }

        /* SHARE BUTTONS */
        .share-section {
            margin-top: 50px;
            padding-top: 30px;
            border-top: 1px solid #eee;
        }
        .share-section h4 { margin-bottom: 15px; color: #0a192f; }
        
        .share-btn-group { display: flex; gap: 10px; flex-wrap: wrap; }
        
        .share-btn {
            display: inline-flex;
            align-items: center;
            padding: 10px 20px;
            border-radius: 5px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: 0.3s;
        }
        .share-btn i { margin-right: 8px; }
        .btn-wa-share { background: #25D366; }
        .btn-fb-share { background: #1877F2; }
        .btn-tw-share { background: #1DA1F2; }
        .share-btn:hover { opacity: 0.8; transform: translateY(-2px); }


        /* --- BAGIAN KANAN (SIDEBAR) --- */
        .sidebar-widget {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .widget-title {
            background: #0a192f; /* Biru Tua sesuai tema kita */
            color: white;
            padding: 12px;
            text-align: center;
            border-radius: 5px;
            font-weight: 600;
            margin-bottom: 20px;
        }

        /* SEARCH FORM */
        .search-form input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .search-form button {
            width: 100%;
            padding: 12px;
            background: #0a192f; /* Tombol Biru */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }
        .search-form button:hover { background: #526af3; }

        /* LIST TERBARU & TERKAIT */
        .recent-list { list-style: none; }
        .recent-item {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
        }
        .recent-item:last-child { border-bottom: none; margin-bottom: 0; }
        .recent-thumb {
            width: 70px;
            height: 70px;
            object-fit: cover;
            border-radius: 5px;
        }
        .recent-info h5 {
            font-size: 0.95rem;
            margin-bottom: 5px;
            line-height: 1.3;
        }
        .recent-info h5 a { text-decoration: none; color: #333; }
        .recent-info h5 a:hover { color: #526af3; }
        .recent-info span { font-size: 0.75rem; color: #888; }

        @media (max-width: 900px) {
            .read-container { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit; display:flex; align-items:center;">
                ROOTBLOWER<span>ID</span>
            </a>
        </div>

        <div class="hamburger" onclick="toggleMenu()">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>

        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link">Home</a> 

            <div class="nav-link dropdown-parent">
                Tipe Root Blower <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="brand_anlet.php">ANLET</a>
                    <a href="brand_futsu.php">FUTSU</a>
                    <a href="brand_tsurumi.php">TSURUMI</a>
                </div>
            </div>

            <div class="nav-link dropdown-parent">
                Aplikasi <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="aplikasi_wwtp.php">WWTP / IPAL</a>
                    <a href="aplikasi_tambak.php">Tambak Udang</a>
                    <a href="aplikasi_aerasi.php">Aeration</a>
                    <a href="aplikasi_bioflok.php">Bioflok</a>
                </div>
            </div>

            <a href="harga.php" class="nav-link">Harga</a>
            <a href="about.php" class="nav-link">About Us</a>
            <a href="blog.php" class="nav-link active">Artikel</a>
            <a href="#kontak" class="btn-contact-mobile">Hubungi Kami</a>
        </div>

        <div class="nav-right">
            <a href="#kontak" class="btn-contact">Hubungi Kami</a>
        </div>
    </nav>

    <div class="read-container">
        
        <div class="article-content">
            
            <div class="breadcrumb-nav">
                <a href="blog.php">Blog</a> 
                <i class="fas fa-chevron-right"></i> 
                <span><?php echo $d['kategori']; ?></span>
            </div>

            <span class="cat-badge"><?php echo $d['kategori']; ?></span>
            
            <div class="article-header">
                <h1><?php echo $d['judul']; ?></h1>
                <div class="article-meta">
                    <span><i class="fas fa-user"></i> <?php echo $d['penulis']; ?></span>
                    <span><i class="far fa-calendar-alt"></i> <?php echo date('d F Y', strtotime($d['tanggal'])); ?></span>
                    <span><i class="far fa-eye"></i> <?php echo $d['views']; ?>x Dibaca</span>
                </div>
            </div>

            <img src="uploads/<?php echo $d['gambar']; ?>" alt="<?php echo $d['deskripsi_gambar']; ?>" class="main-image">
            <div class="img-caption"><?php echo $d['deskripsi_gambar']; ?></div>

            <div class="article-text">
                <?php echo nl2br($d['isi']); ?>
            </div>

            <div class="share-section">
                <h4>Bagikan Artikel ini:</h4>
                <div class="share-btn-group">
                    <?php $current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
                    
                    <a href="https://wa.me/?text=<?php echo urlencode($d['judul'] . ' - ' . $current_url); ?>" target="_blank" class="share-btn btn-wa-share">
                        <i class="fab fa-whatsapp"></i> WhatsApp
                    </a>
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($current_url); ?>" target="_blank" class="share-btn btn-fb-share">
                        <i class="fab fa-facebook-f"></i> Facebook
                    </a>
                    <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode($d['judul']); ?>&url=<?php echo urlencode($current_url); ?>" target="_blank" class="share-btn btn-tw-share">
                        <i class="fab fa-twitter"></i> Twitter
                    </a>
                </div>
            </div>
        </div>

        <div class="sidebar">
            
            <div class="sidebar-widget">
                <div class="widget-title">Cari Artikel</div>
                <form action="blog.php" method="GET" class="search-form">
                    <input type="text" name="cari" placeholder="Kata kunci...">
                    <button type="submit"><i class="fas fa-search"></i> Cari</button>
                </form>
            </div>

            <div class="sidebar-widget">
                <div class="widget-title">Blog Terbaru</div>
                <ul class="recent-list">
                    <?php
                    $recent = mysqli_query($conn, "SELECT * FROM artikel WHERE id != '$id' ORDER BY id DESC LIMIT 5");
                    while($rec = mysqli_fetch_assoc($recent)){
                    ?>
                    <li class="recent-item">
                        <img src="uploads/<?php echo $rec['gambar']; ?>" class="recent-thumb">
                        <div class="recent-info">
                            <h5><a href="baca_artikel.php?id=<?php echo $rec['id']; ?>"><?php echo substr($rec['judul'], 0, 45); ?></a></h5>
                            <span><i class="far fa-clock"></i> <?php echo date('d M Y', strtotime($rec['tanggal'])); ?></span>
                        </div>
                    </li>
                    <?php } ?>
                </ul>
            </div>

            <div class="sidebar-widget">
                <div class="widget-title">Terpopuler</div>
                <ul class="recent-list">
                    <?php
                    $pop = mysqli_query($conn, "SELECT * FROM artikel ORDER BY views DESC LIMIT 3");
                    while($p = mysqli_fetch_assoc($pop)){
                    ?>
                    <li class="recent-item">
                        <div class="recent-info" style="width:100%;">
                            <h5 style="margin-bottom:5px;"><a href="baca_artikel.php?id=<?php echo $p['id']; ?>"><?php echo $p['judul']; ?></a></h5>
                            <span style="color:#64ffda; font-weight:600;"><i class="fas fa-eye"></i> <?php echo $p['views']; ?> Views</span>
                        </div>
                    </li>
                    <?php } ?>
                </ul>
            </div>

            <div class="sidebar-widget">
                <div class="widget-title">Artikel Terkait</div>
                <ul class="recent-list">
                    <?php
                    // Ambil artikel yang KATEGORINYA SAMA tapi ID-nya BUKAN yang sedang dibaca
                    $kategori_terkait = $d['kategori'];
                    $terkait = mysqli_query($conn, "SELECT * FROM artikel WHERE kategori = '$kategori_terkait' AND id != '$id' LIMIT 5");

                    if(mysqli_num_rows($terkait) > 0) {
                        while($rel = mysqli_fetch_assoc($terkait)){
                    ?>
                        <li class="recent-item">
                            <img src="uploads/<?php echo $rel['gambar']; ?>" class="recent-thumb">
                            <div class="recent-info">
                                <h5><a href="baca_artikel.php?id=<?php echo $rel['id']; ?>"><?php echo substr($rel['judul'], 0, 40); ?></a></h5>
                                <span style="font-size:0.7rem; color:#64ffda;"><i class="fas fa-tag"></i> <?php echo $rel['kategori']; ?></span>
                            </div>
                        </li>
                    <?php 
                        }
                    } else {
                        // Tampilan jika tidak ada artikel terkait
                        echo '<li class="recent-item" style="color:#888; font-style:italic; justify-content:center;">Belum ada artikel terkait.</li>';
                    }
                    ?>
                </ul>
            </div>

        </div>
    </div>

    <footer id="kontak">
        <div class="footer-content">
            
            <div class="footer-section">
                <h3>PT YUAN ADAM</h3>
                <p style="margin-bottom: 25px;">Distributor Root Blower terpercaya sejak 2026. Solusi tepat untuk pengolahan limbah dan aerasi industri.</p>

                <h4 style="color: #64ffda; margin-bottom: 15px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;">Follow Us</h4>
                <div class="social-links">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h3>Office</h3>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Head Office:</strong><br>
                    Jl. Basuki Rahmat No. 2 Batang - Jawa Tengah
                </div>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Semarang Office:</strong><br>
                    Jl. KS Tubun No.23 Ungaran Semarang - Jawa Tengah
                </div>
                <div>
                    <strong style="color: #fff;">Surabaya Office:</strong><br>
                    Ruko Galaxi Bumi Permai Blok J1/23A Jl. Raya Sukosemolo,  Semolowaru Sukolilo - Surabaya
                </div>
            </div>

            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Jl. Industri Raya No. 123, Indonesia</p>
                <p><i class="fas fa-phone"></i> +62 812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> admin@rootblower.id</p>
            </div>

        </div>
        
        <div class="copyright">
            <p>&copy; 2026 PT Yuan Adam. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Script Buka-Tutup Menu Panel
        function toggleMenu() {
            var menu = document.getElementById("navMenu");
            var hamburger = document.querySelector(".hamburger");
            menu.classList.toggle("active");
            hamburger.classList.toggle("active");
        }

        // --- TAMBAHAN BARU: SCRIPT DROPDOWN MOBILE --- //
        
        // Ambil semua elemen yang punya anak dropdown
        var dropdowns = document.querySelectorAll('.dropdown-parent');

        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(e) {
                // Cek apakah layar sedang mode HP (<= 991px)
                if (window.innerWidth <= 991) {
                    
                    // Kalau yang diklik bukan link di dalamnya (biar link anak tetep jalan)
                    if (e.target === this || e.target.tagName === 'I' || e.target.textContent.trim() === this.firstChild.textContent.trim()) {
                        
                        // Toggle class 'active' buat buka/tutup
                        this.classList.toggle('active');
                        
                        // Opsional: Tutup dropdown lain biar gak rame (Accordion effect)
                        dropdowns.forEach(function(other) {
                            if (other !== dropdown) {
                                other.classList.remove('active');
                            }
                        });
                    }
                }
            });
        });
    </script>

</body>
</html>
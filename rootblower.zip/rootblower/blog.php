<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artikel & Berita - PT Yuan Adam</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* HEADER HALAMAN ARTIKEL */
        .blog-header {
            background: linear-gradient(rgba(10, 25, 47, 0.95), rgba(10, 25, 47, 0.9)), url('assets/img/bg.jpg');
            background-size: cover;
            background-position: center;
            padding: 80px 5%;
            text-align: center;
            color: white;
            margin-bottom: 50px;
        }

        /* LAYOUT UTAMA (KIRI KONTEN, KANAN SIDEBAR) */
        .blog-container {
            display: grid;
            grid-template-columns: 2.5fr 1fr; /* Kiri lebih lebar (70%), Kanan (30%) */
            gap: 40px;
            padding: 0 5% 80px;
            max-width: 1400px;
            margin: 0 auto;
        }

        /* --- KIRI: GRID ARTIKEL (2 KOLOM) --- */
        .article-grid {
            display: grid;
            grid-template-columns: 1fr 1fr; /* 2 Artikel per baris */
            gap: 30px;
        }

        .article-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: 0.3s;
            border: 1px solid #eee;
            display: flex;
            flex-direction: column;
        }

        .article-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }

        .article-thumb {
            width: 100%;
            height: 200px; /* Tinggi gambar seragam */
            object-fit: cover;
        }

        .article-body {
            padding: 20px;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }

        .article-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: #0a192f;
            margin-bottom: 10px;
            line-height: 1.4;
        }
        .article-title a { text-decoration: none; color: inherit; }
        .article-title a:hover { color: #526af3; }

        .article-meta {
            font-size: 0.8rem;
            color: #888;
            margin-bottom: 15px;
            display: flex;
            gap: 15px;
        }
        .article-meta i { color: #64ffda; margin-right: 5px; }

        .article-excerpt {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 20px;
            line-height: 1.6;
            flex-grow: 1;
        }

        .btn-read-more {
            display: inline-block;
            background: #0a192f;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 0.85rem;
            font-weight: 600;
            text-decoration: none;
            transition: 0.3s;
            text-align: center;
        }
        .btn-read-more:hover { background: #112240; }


        /* --- KANAN: SIDEBAR --- */
        .sidebar-widget {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            border: 1px solid #eee;
        }

        .widget-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: #0a192f;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #64ffda;
        }

        /* Form Pencarian */
        .search-box { display: flex; gap: 5px; }
        .search-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        .search-btn {
            background: #0a192f;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        /* List Kategori & Recent Post */
        .widget-list { list-style: none; padding: 0; }
        .widget-list li {
            border-bottom: 1px solid #eee;
            padding: 10px 0;
            font-size: 0.9rem;
        }
        .widget-list li:last-child { border-bottom: none; }
        .widget-list li a { text-decoration: none; color: #555; transition: 0.2s; display: flex; justify-content: space-between; }
        .widget-list li a:hover { color: #526af3; padding-left: 5px; }

        .recent-post-item {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            align-items: center;
        }
        .recent-post-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
        }
        .recent-post-info h5 {
            font-size: 0.9rem;
            margin-bottom: 5px;
            line-height: 1.3;
        }
        .recent-post-info h5 a { text-decoration: none; color: #0a192f; }
        .recent-post-info small { color: #888; font-size: 0.75rem; }

        /* RESPONSIVE */
        @media (max-width: 900px) {
            .blog-container { grid-template-columns: 1fr; }
            .article-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit; display:flex; align-items:center;">
                ROOTBLOWER<span>ID</span>
            </a>
        </div>

        <div class="hamburger" onclick="toggleMenu()">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>

        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link">Home</a> 

            <div class="nav-link dropdown-parent">
                Tipe Root Blower <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="brand_anlet.php">ANLET</a>
                    <a href="brand_futsu.php">FUTSU</a>
                    <a href="brand_tsurumi.php">TSURUMI</a>
                </div>
            </div>

            <div class="nav-link dropdown-parent">
                Aplikasi <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="aplikasi_wwtp.php">WWTP / IPAL</a>
                    <a href="aplikasi_tambak.php">Tambak Udang</a>
                    <a href="aplikasi_aerasi.php">Aeration</a>
                    <a href="aplikasi_bioflok.php">Bioflok</a>
                </div>
            </div>

            <a href="harga.php" class="nav-link">Harga</a>
            <a href="about.php" class="nav-link">About Us</a>
            <a href="blog.php" class="nav-link active">Artikel</a>
            <a href="#kontak" class="btn-contact-mobile">Hubungi Kami</a>
        </div>

        <div class="nav-right">
            <a href="#kontak" class="btn-contact">Hubungi Kami</a>
        </div>
    </nav>

    <header class="blog-header">
        <h1 style="font-size: 3rem; margin-bottom: 10px;">Artikel & Berita Industri</h1>
        <p style="font-size: 1.2rem; color: #64ffda; font-weight: 500;">Wawasan Terbaru Seputar Root Blower, IPAL, dan Tambak</p>
    </header>

    <div class="blog-container">
        
        <main>
            <?php
            $search_query = "";
            if(isset($_GET['cari'])){
                $cari = mysqli_real_escape_string($conn, $_GET['cari']);
                $search_query = " WHERE judul LIKE '%$cari%' OR isi LIKE '%$cari%' OR kategori LIKE '%$cari%' ";
                echo "<h3 style='margin-bottom:20px; color:#555;'>Hasil pencarian: \"$cari\"</h3>";
            }
            ?>

            <div class="article-grid">
                <?php
                // Query Artikel Utama
                $query = mysqli_query($conn, "SELECT * FROM artikel $search_query ORDER BY id DESC");
                
                if(mysqli_num_rows($query) > 0){
                    while($row = mysqli_fetch_assoc($query)){
                ?>
                    <div class="article-card">
                        <img src="uploads/<?php echo $row['gambar']; ?>" alt="<?php echo $row['judul']; ?>" class="article-thumb">
                        
                        <div class="article-body">
                            <a href="blog.php?cari=<?php echo urlencode($row['kategori']); ?>" style="text-decoration:none;">
                                <span style="background:#e0f2fe; color:#0284c7; padding:4px 10px; border-radius:4px; font-size:0.75rem; font-weight:700; display:inline-block; margin-bottom:10px; width:fit-content; transition:0.3s;">
                                    <?php echo $row['kategori']; ?>
                                </span>
                            </a>

                            <h3 class="article-title">
                                <a href="baca_artikel.php?id=<?php echo $row['id']; ?>"><?php echo $row['judul']; ?></a>
                            </h3>
                            
                            <div class="article-meta">
                                <span><i class="far fa-calendar-alt"></i> <?php echo date('d M Y', strtotime($row['tanggal'])); ?></span>
                                <span><i class="far fa-eye"></i> <?php echo $row['views']; ?> Views</span>
                            </div>
                            
                            <p class="article-excerpt">
                                <?php echo substr($row['rangkuman'], 0, 90); ?>
                            </p>
                            
                            <a href="baca_artikel.php?id=<?php echo $row['id']; ?>" class="btn-read-more">Baca Selengkapnya</a>
                        </div>
                    </div>
                <?php 
                    }
                } else {
                    echo "<p style='grid-column: span 2; text-align:center; padding:50px; background:#fff; border-radius:10px;'>Belum ada artikel yang ditemukan.</p>";
                }
                ?>
            </div>
        </main>

        <aside>
            
            <div class="sidebar-widget">
                <h4 class="widget-title">Cari Artikel</h4>
                <form action="blog.php" method="GET" class="search-box">
                    <input type="text" name="cari" class="search-input" placeholder="Kata kunci...">
                    <button type="submit" class="search-btn"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div class="sidebar-widget">
                <h4 class="widget-title">Terbaru</h4>
                <?php
                // Ambil 5 artikel terbaru berdasarkan ID (terakhir diupload)
                $recent = mysqli_query($conn, "SELECT * FROM artikel ORDER BY id DESC LIMIT 5");
                while($rec = mysqli_fetch_assoc($recent)){
                ?>
                <div class="recent-post-item">
                    <img src="uploads/<?php echo $rec['gambar']; ?>" class="recent-post-img">
                    <div class="recent-post-info">
                        <h5><a href="detail_artikel.php?id=<?php echo $rec['id']; ?>"><?php echo substr($rec['judul'], 0, 40); ?></a></h5>
                        <small><i class="far fa-clock"></i> <?php echo date('d M Y', strtotime($rec['tanggal'])); ?></small>
                    </div>
                </div>
                <hr style="border:0; border-top:1px solid #eee; margin:10px 0;">
                <?php } ?>
            </div>

            <div class="sidebar-widget">
                <h4 class="widget-title"> Terpopuler</h4>
                <?php
                // Ambil 5 artikel terpopuler berdasarkan VIEWS terbanyak
                $populer = mysqli_query($conn, "SELECT * FROM artikel ORDER BY views DESC LIMIT 5");
                while($pop = mysqli_fetch_assoc($populer)){
                ?>
                <div class="recent-post-item">
                    <img src="uploads/<?php echo $pop['gambar']; ?>" class="recent-post-img">
                    <div class="recent-post-info">
                        <h5><a href="detail_artikel.php?id=<?php echo $pop['id']; ?>"><?php echo substr($pop['judul'], 0, 40); ?></a></h5>
                        <small style="color:#64ffda; font-weight:600;"><i class="far fa-eye"></i> <?php echo $pop['views']; ?> Views</small>
                    </div>
                </div>
                <hr style="border:0; border-top:1px solid #eee; margin:10px 0;">
                <?php } ?>
            </div>

            <div class="sidebar-widget">
                <h4 class="widget-title">Kategori Artikel</h4>
                <ul class="widget-list">
                    <li><a href="blog.php?cari=IPAL"><span>IPAL & WWTP</span> <i class="fas fa-chevron-right" style="font-size:0.7rem;"></i></a></li>
                    <li><a href="blog.php?cari=Tambak"><span>Tambak Udang</span> <i class="fas fa-chevron-right" style="font-size:0.7rem;"></i></a></li>
                    <li><a href="blog.php?cari=Tips"><span>Tips Perawatan</span> <i class="fas fa-chevron-right" style="font-size:0.7rem;"></i></a></li>
                    <li><a href="blog.php?cari=Berita"><span>Berita Perusahaan</span> <i class="fas fa-chevron-right" style="font-size:0.7rem;"></i></a></li>
                    <li><a href="blog.php?cari=Aerasi"><span>Aerasi & Blower</span> <i class="fas fa-chevron-right" style="font-size:0.7rem;"></i></a></li>
                </ul>
            </div>

            <div class="sidebar-widget" style="background: #0a192f; color: white; text-align: center;">
                <i class="fab fa-whatsapp" style="font-size: 3rem; color: #25D366; margin-bottom: 10px;"></i>
                <h4 style="color: white; margin-bottom: 10px;">Butuh Bantuan?</h4>
                <p style="font-size: 0.9rem; margin-bottom: 20px; color: #ddd;">Konsultasikan kebutuhan blower Anda dengan tim ahli kami.</p>
                <a href="https://wa.me/6285842556218" target="_blank" style="background: #25D366; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: bold; display: block;">Chat WhatsApp</a>
            </div>

        </aside>

    </div>

    <footer id="kontak">
        <div class="footer-content">
            
            <div class="footer-section">
                <h3>PT YUAN ADAM</h3>
                <p style="margin-bottom: 25px;">Distributor Root Blower terpercaya sejak 2026. Solusi tepat untuk pengolahan limbah dan aerasi industri.</p>

                <h4 style="color: #64ffda; margin-bottom: 15px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;">Follow Us</h4>
                <div class="social-links">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h3>Office</h3>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Head Office:</strong><br>
                    Jl. Basuki Rahmat No. 2 Batang - Jawa Tengah
                </div>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Semarang Office:</strong><br>
                    Jl. KS Tubun No.23 Ungaran Semarang - Jawa Tengah
                </div>
                <div>
                    <strong style="color: #fff;">Surabaya Office:</strong><br>
                    Ruko Galaxi Bumi Permai Blok J1/23A Jl. Raya Sukosemolo,  Semolowaru Sukolilo - Surabaya
                </div>
            </div>

            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Jl. Industri Raya No. 123, Indonesia</p>
                <p><i class="fas fa-phone"></i> +62 812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> admin@rootblower.id</p>
            </div>

        </div>
        
        <div class="copyright">
            <p>&copy; 2026 PT Yuan Adam. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Script Buka-Tutup Menu Panel
        function toggleMenu() {
            var menu = document.getElementById("navMenu");
            var hamburger = document.querySelector(".hamburger");
            menu.classList.toggle("active");
            hamburger.classList.toggle("active");
        }

        // --- TAMBAHAN BARU: SCRIPT DROPDOWN MOBILE --- //
        
        // Ambil semua elemen yang punya anak dropdown
        var dropdowns = document.querySelectorAll('.dropdown-parent');

        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(e) {
                // Cek apakah layar sedang mode HP (<= 991px)
                if (window.innerWidth <= 991) {
                    
                    // Kalau yang diklik bukan link di dalamnya (biar link anak tetep jalan)
                    if (e.target === this || e.target.tagName === 'I' || e.target.textContent.trim() === this.firstChild.textContent.trim()) {
                        
                        // Toggle class 'active' buat buka/tutup
                        this.classList.toggle('active');
                        
                        // Opsional: Tutup dropdown lain biar gak rame (Accordion effect)
                        dropdowns.forEach(function(other) {
                            if (other !== dropdown) {
                                other.classList.remove('active');
                            }
                        });
                    }
                }
            });
        });
    </script>

</body>
</html>
<?php
session_start();
include '../db.php';

// Cek Login
if (!isset($_SESSION['admin'])) { 
    header("Location: login.php"); 
    exit(); 
}

// --- DATA QUERY UNTUK DASHBOARD ---
// 1. Hitung Total Produk
$prod_query = mysqli_query($conn, "SELECT COUNT(*) as total FROM produk");
$prod_data = mysqli_fetch_assoc($prod_query);
$total_produk = $prod_data['total'];

// 2. Hitung Total Artikel
$art_query = mysqli_query($conn, "SELECT COUNT(*) as total FROM artikel");
$art_data = mysqli_fetch_assoc($art_query);
$total_artikel = $art_data['total'];

// 3. Ambil 5 Produk Terakhir (Untuk Tabel Recent)
$recent_query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC LIMIT 5");

// 4. Waktu Greeting (Otomatis)
date_default_timezone_set('Asia/Jakarta');
$jam = date('H');
if ($jam >= 5 && $jam < 12) $sapaan = "Selamat Pagi";
elseif ($jam >= 12 && $jam < 15) $sapaan = "Selamat Siang";
elseif ($jam >= 15 && $jam < 18) $sapaan = "Selamat Sore";
else $sapaan = "Selamat Malam";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --sidebar-bg: #0a192f;
            --main-bg: #f0f2f5;
            --card-bg: #ffffff;
            --accent: #64ffda;
            --text-dark: #1e293b;
            --text-light: #64748b;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--main-bg); display: flex; min-height: 100vh; overflow-x: hidden; }
        a { text-decoration: none; }

        /* SIDEBAR STYLE */
        .sidebar {
            width: 260px;
            background: var(--sidebar-bg);
            color: #fff;
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: 0.3s;
            box-shadow: 4px 0 20px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 40px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        
        .sidebar-header h3 { color: var(--accent); letter-spacing: 1px; margin-top: 10px; font-weight: 800; }

        .menu-container { padding: 20px 10px; }
        .menu-item {
            display: flex;
            padding: 15px 20px;
            color: #a8b2d1;
            transition: 0.3s;
            align-items: center;
            border-radius: 8px;
            margin-bottom: 5px;
            font-size: 0.95rem;
        }
        
        .menu-item:hover, .menu-item.active {
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent);
            transform: translateX(5px);
        }
        
        .menu-item i { width: 35px; font-size: 1.1rem; }

        /* MAIN CONTENT */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            padding: 30px;
        }

        /* HEADER */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }
        .user-info h2 { font-size: 1.8rem; color: var(--text-dark); }
        .user-info p { color: var(--text-light); }
        
        .date-badge {
            background: #fff;
            padding: 10px 20px;
            border-radius: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            color: var(--text-dark);
            font-weight: 600;
            display: flex; align-items: center; gap: 10px;
        }

        /* STATS CARDS (UPDATE: Cuma 2 Kolom) */
        .stats-grid {
            display: grid;
            /* Ubah jadi 2 kolom rata */
            grid-template-columns: 1fr 1fr; 
            gap: 25px;
            margin-bottom: 40px;
        }

        .stat-card {
            padding: 30px; /* Gedein padding dikit biar mantap */
            border-radius: 15px;
            color: white;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            min-height: 160px; /* Tinggi minimal biar gagah */
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .stat-card:hover { transform: translateY(-5px); }

        /* Warna Card */
        .card-blue { background: linear-gradient(135deg, #3b82f6, #2563eb); }
        .card-purple { background: linear-gradient(135deg, #8b5cf6, #6d28d9); }

        .stat-card h3 { font-size: 3rem; font-weight: 700; margin-bottom: 5px; line-height: 1; }
        .stat-card p { font-size: 1.1rem; opacity: 0.9; font-weight: 500; }
        
        .stat-card .icon-bg {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 5rem; /* Ikon digedein */
            opacity: 0.2;
        }

        /* DASHBOARD WIDGETS LAYOUT */
        .dashboard-widgets {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 25px;
        }

        /* TABLE SECTION */
        .recent-table-container {
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03);
        }
        .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .section-header h4 { font-size: 1.2rem; color: var(--text-dark); }
        .btn-view-all { font-size: 0.85rem; color: #3b82f6; font-weight: 600; }

        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 15px 10px; color: var(--text-light); font-size: 0.85rem; border-bottom: 1px solid #eee; }
        td { padding: 15px 10px; color: var(--text-dark); font-size: 0.9rem; border-bottom: 1px solid #f9f9f9; }
        tr:hover td { background: #f8fafc; }
        .status-badge { background: #dcfce7; color: #166534; padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; }

        /* RIGHT SIDEBAR WIDGETS */
        .quick-actions {
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03);
            margin-bottom: 25px;
        }
        .action-btn {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: #f8fafc;
            border-radius: 10px;
            color: var(--text-dark);
            margin-bottom: 15px;
            transition: 0.3s;
            border: 1px solid transparent;
        }
        .action-btn:hover { background: #fff; border-color: #3b82f6; transform: translateX(5px); box-shadow: 0 5px 15px rgba(59, 130, 246, 0.1); }
        .icon-box { width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; }
        
        .server-status {
            background: linear-gradient(135deg, #0a192f, #112240);
            padding: 25px;
            border-radius: 15px;
            color: white;
        }
        .status-item { display: flex; justify-content: space-between; margin-bottom: 15px; font-size: 0.9rem; }
        .progress-bar { width: 100%; height: 6px; background: rgba(255,255,255,0.1); border-radius: 10px; margin-top: 5px; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 10px; }

        /* Responsive */
        @media (max-width: 1024px) {
            .dashboard-widgets { grid-template-columns: 1fr; }
            .sidebar { width: 80px; text-align: center; }
            .sidebar h3, .menu-item span { display: none; }
            .main-content { margin-left: 80px; width: calc(100% - 80px); }
            .menu-item { justify-content: center; padding: 15px; }
            .menu-item i { margin: 0; width: auto; font-size: 1.5rem; }
            .stats-grid { grid-template-columns: 1fr; } /* Di HP jadi 1 kolom ke bawah */
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-fan fa-2x" style="color: #64ffda;"></i>
            <h3>ADMIN PANEL</h3>
        </div>
        <div class="menu-container">
            <a href="dashboard.php" class="menu-item active"><i class="fas fa-th-large"></i> <span>Dashboard</span></a>
            <a href="produk.php" class="menu-item"><i class="fas fa-wind"></i> <span>Data Root Blower</span></a>
            <a href="artikel.php" class="menu-item"><i class="fas fa-newspaper"></i> <span>Artikel & Berita</span></a>
            <a href="../index.php" target="_blank" class="menu-item"><i class="fas fa-globe"></i> <span>Lihat Website</span></a>
            <a href="logout.php" class="menu-item" style="color: #ff6b6b; margin-top: 50px;"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </div>

    <div class="main-content">
        
        <div class="top-bar">
            <div class="user-info">
                <h2><?php echo $sapaan; ?>, Admin! 👋</h2>
                <p>Berikut adalah ringkasan performa website Anda hari ini.</p>
            </div>
            <div class="date-badge">
                <i class="far fa-calendar-alt" style="color: #3b82f6;"></i>
                <?php echo date('d F Y'); ?>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card card-blue">
                <i class="fas fa-wind icon-bg"></i>
                <h3><?php echo $total_produk; ?></h3>
                <p>Total Unit Root Blower</p>
            </div>
            
            <div class="stat-card card-purple">
                <i class="fas fa-newspaper icon-bg"></i>
                <h3><?php echo $total_artikel; ?></h3>
                <p>Artikel Terpublikasi</p>
            </div>
        </div>

        <div class="dashboard-widgets">
            
            <div class="recent-table-container">
                <div class="section-header">
                    <h4><i class="fas fa-history" style="color:#64748b; margin-right:10px;"></i> Upload Terbaru</h4>
                    <a href="produk.php" class="btn-view-all">Lihat Semua</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Nama Produk</th>
                            <th>Model</th>
                            <th>Tanggal Upload</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if(mysqli_num_rows($recent_query) > 0){
                            while($row = mysqli_fetch_assoc($recent_query)){
                        ?>
                        <tr>
                            <td style="font-weight: 600;"><?php echo $row['nama']; ?></td>
                            <td><?php echo isset($row['model']) ? substr($row['model'], 0, 20).'...' : '-'; ?></td>
                            <td><?php echo date('d/m/Y'); ?></td>
                            <td><span class="status-badge">Active</span></td>
                        </tr>
                        <?php 
                            }
                        } else {
                            echo "<tr><td colspan='4' style='text-align:center;'>Belum ada data</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <div class="right-widgets">
                
                <div class="quick-actions">
                    <div class="section-header">
                        <h4>Aksi Cepat</h4>
                    </div>
                    <a href="tambah_produk.php" class="action-btn">
                        <div class="icon-box" style="background: #3b82f6;"><i class="fas fa-plus"></i></div>
                        <div>
                            <h5 style="font-size: 0.95rem; margin-bottom: 2px;">Tambah Produk</h5>
                            <span style="font-size: 0.75rem; color: #888;">Upload unit baru</span>
                        </div>
                    </a>
                    <a href="tambah_artikel.php" class="action-btn">
                        <div class="icon-box" style="background: #8b5cf6;"><i class="fas fa-pen"></i></div>
                        <div>
                            <h5 style="font-size: 0.95rem; margin-bottom: 2px;">Tulis Artikel</h5>
                            <span style="font-size: 0.75rem; color: #888;">Buat berita baru</span>
                        </div>
                    </a>
                </div>

                <div class="server-status">
                    <h4 style="margin-bottom: 20px; font-size: 1rem;"><i class="fas fa-server"></i> Server Status</h4>
                    
                    <div class="status-item">
                        <span>Storage Usage</span>
                        <span>45%</span>
                    </div>
                    <div class="progress-bar"><div class="progress-fill" style="width: 45%; background: #64ffda;"></div></div>
                    
                    <div class="status-item" style="margin-top: 15px;">
                        <span>Bandwidth</span>
                        <span>68%</span>
                    </div>
                    <div class="progress-bar"><div class="progress-fill" style="width: 68%; background: #f59e0b;"></div></div>

                    <div style="margin-top: 20px; font-size: 0.8rem; opacity: 0.7;">
                        <i class="fas fa-circle" style="color: #25D366; font-size: 0.6rem;"></i> System Running Smoothly
                    </div>
                </div>

            </div>
        </div>

    </div>

</body>
</html>
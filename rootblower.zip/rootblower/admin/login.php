<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Administrator - PT Yuan Adam</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* --- CSS KHUSUS HALAMAN LOGIN --- */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }

        body {
            background-color: #0a192f;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .login-container {
            background: #ffffff;
            width: 100%;
            max-width: 400px;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .login-container::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 5px;
            background: linear-gradient(90deg, #64ffda, #0a192f);
        }

        .brand-title { font-size: 1.8rem; font-weight: 700; color: #0a192f; margin-bottom: 5px; }
        .brand-subtitle { font-size: 0.9rem; color: #888; margin-bottom: 30px; }

        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; margin-bottom: 8px; font-size: 0.9rem; font-weight: 600; color: #555; }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: 0.3s;
            background-color: #f9f9f9;
        }

        .form-group input:focus {
            border-color: #0a192f;
            background-color: #fff;
            outline: none;
            box-shadow: 0 0 0 3px rgba(10, 25, 47, 0.1);
        }

        /* --- STYLE BARU UNTUK PASSWORD WRAPPER --- */
        .password-wrapper {
            position: relative; /* Agar ikon bisa diposisikan absolute terhadap div ini */
        }
        
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #888;
            font-size: 1rem;
        }
        
        .toggle-password:hover { color: #0a192f; }

        /* --- STYLE LINK LUPA SANDI --- */
        .forgot-pass-link {
            display: block;
            text-align: right;
            font-size: 0.85rem;
            color: #0a192f;
            text-decoration: none;
            margin-top: 5px;
            font-weight: 500;
        }
        .forgot-pass-link:hover { text-decoration: underline; color: #64ffda; }

        .btn-login {
            width: 100%;
            padding: 12px;
            background-color: #0a192f;
            color: #64ffda;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 15px;
        }

        .btn-login:hover {
            background-color: #172a45;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(10, 25, 47, 0.3);
        }

        .back-link {
            display: block;
            margin-top: 25px;
            font-size: 0.9rem;
            color: #888;
            text-decoration: none;
            transition: 0.3s;
        }
        .back-link:hover { color: #0a192f; }

        @media (max-width: 480px) {
            .login-container { width: 90%; padding: 30px 20px; }
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2 class="brand-title">ADMIN PANEL</h2>
        <p class="brand-subtitle">PT Yuan Adam Root Blower</p>

        <form action="proses.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Masukkan username" required autocomplete="off">
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" placeholder="Masukkan password" required>
                    <i class="fas fa-eye toggle-password" onclick="togglePassword()"></i>
                </div>
                
                <a href="lupa_password.php" class="forgot-pass-link">Lupa Kata Sandi?</a>
            </div>

            <button type="submit" name="login" class="btn-login">MASUK DASHBOARD</button>
        </form>

        <a href="../index.php" class="back-link">
            &larr; Kembali ke Website Utama
        </a>
    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById("password");
            const toggleIcon = document.querySelector(".toggle-password");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleIcon.classList.remove("fa-eye");
                toggleIcon.classList.add("fa-eye-slash"); // Ubah ikon jadi mata dicoret
            } else {
                passwordField.type = "password";
                toggleIcon.classList.remove("fa-eye-slash");
                toggleIcon.classList.add("fa-eye"); // Ubah ikon jadi mata biasa
            }
        }
    </script>

</body>
</html>
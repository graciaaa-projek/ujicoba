<?php
include '../db.php'; // Pastikan koneksi database terhubung

$pesan = "";
$status = ""; // sukses atau error

if (isset($_POST['cek_username'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    
    // Cek apakah username ada di database
    $cek = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
    
    if (mysqli_num_rows($cek) > 0) {
        // Jika username ada
        $status = "sukses";
        $pesan = "Username ditemukan! Klik tombol di bawah untuk reset via WhatsApp.";
    } else {
        // Jika username tidak ada
        $status = "error";
        $pesan = "Username tidak terdaftar dalam sistem.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* --- CSS RESET & BASIC --- */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }

        body {
            background-color: #0a192f; /* Dark Navy */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .reset-container {
            background: #ffffff;
            width: 100%;
            max-width: 450px;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        /* Garis Hiasan Atas (Aksen Orange/Warning) */
        .reset-container::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 5px;
            background: linear-gradient(90deg, #ff6b6b, #feca57);
        }

        .icon-lock {
            font-size: 3rem;
            color: #0a192f;
            margin-bottom: 20px;
            background: #f0f2f5;
            width: 80px;
            height: 80px;
            line-height: 80px;
            border-radius: 50%;
            display: inline-block;
        }

        .title { font-size: 1.5rem; font-weight: 700; color: #0a192f; margin-bottom: 10px; }
        .subtitle { font-size: 0.9rem; color: #666; margin-bottom: 30px; line-height: 1.5; }

        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: #555; font-size: 0.9rem; }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: 0.3s;
            background-color: #f9f9f9;
        }
        
        .form-group input:focus {
            border-color: #0a192f;
            background-color: #fff;
            outline: none;
            box-shadow: 0 0 0 3px rgba(10, 25, 47, 0.1);
        }

        .btn-check {
            width: 100%;
            padding: 12px;
            background-color: #0a192f;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-check:hover { background-color: #172a45; transform: translateY(-2px); }

        .btn-wa {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: #25D366; /* WA Green */
            color: white;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            margin-top: 15px;
        }
        .btn-wa:hover { background-color: #1ebc57; }

        .back-link {
            display: block;
            margin-top: 25px;
            font-size: 0.9rem;
            color: #888;
            text-decoration: none;
        }
        .back-link:hover { color: #0a192f; text-decoration: underline; }

        /* Alert Messages */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            text-align: left;
        }
        .alert-error { background-color: #ffe5e5; color: #d63031; border: 1px solid #fab1a0; }
        .alert-success { background-color: #e3fcef; color: #00b894; border: 1px solid #55efc4; }

    </style>
</head>
<body>

    <div class="reset-container">
        <div class="icon-lock">
            <i class="fas fa-lock-open"></i>
        </div>
        <h2 class="title">Lupa Kata Sandi?</h2>
        
        <?php if ($status == 'sukses') { ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $pesan; ?>
            </div>
            <p class="subtitle">Karena alasan keamanan, silakan kirim permintaan reset manual ke Developer/Super Admin.</p>
            
            <a href="https://wa.me/6289517227484?text=Halo%20Admin,%20saya%20pemilik%20akun%20Username:%20*<?php echo $_POST['username']; ?>*%20ingin%20meminta%20reset%20password." class="btn-wa" target="_blank">
                <i class="fab fa-whatsapp"></i> Hubungi Admin via WA
            </a>

        <?php } else { ?>
            <p class="subtitle">Masukkan username Anda yang terdaftar. Sistem akan memverifikasi data Anda terlebih dahulu.</p>

            <?php if ($status == 'error') { ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $pesan; ?>
                </div>
            <?php } ?>

            <form action="" method="POST">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="" required autocomplete="off">
                </div>
                <button type="submit" name="cek_username" class="btn-check">Verifikasi Username</button>
            </form>
        <?php } ?>

        <a href="login.php" class="back-link">
            &larr; Kembali ke Halaman Login
        </a>
    </div>

</body>
</html>
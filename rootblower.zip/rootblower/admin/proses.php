<?php
session_start();
include '../db.php';

// 1. LOGIN
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $result = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) === 1) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin'] = true;
            header("Location: dashboard.php");
            exit;
        }
    }
    echo "<script>alert('Login Gagal!'); window.location='login.php';</script>";
}

// 2. TAMBAH PRODUK
if (isset($_POST['tambah_produk'])) {
    $nama = $_POST['nama'];
    $model = $_POST['model'];
    $pressure = $_POST['pressure'];
    $capacity = $_POST['capacity'];
    $power = $_POST['power'];
    $deskripsi = $_POST['deskripsi'];

    // Upload Gambar
    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
    $new_name = time() . '-' . $gambar;
    $path = "../uploads/" . $new_name;

    if (move_uploaded_file($tmp, $path)) {
        $query = "INSERT INTO produk (nama, model, pressure, capacity, power, deskripsi, gambar) 
                  VALUES ('$nama', '$model', '$pressure', '$capacity', '$power', '$deskripsi', '$new_name')";
        mysqli_query($conn, $query);
        echo "<script>alert('Produk Berhasil Ditambah!'); window.location='produk.php?page=produk';</script>";
    } else {
        echo "<script>alert('Gagal Upload Gambar'); window.location='edit_produk.php?page=produk';</script>";
    }
}

// 3. UPDATE PRODUK (BARU)
if (isset($_POST['update_produk'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $model = $_POST['model'];
    $pressure = $_POST['pressure'];
    $capacity = $_POST['capacity'];
    $power = $_POST['power'];
    $deskripsi = $_POST['deskripsi'];

    // Cek apakah ada gambar baru?
    $gambar = $_FILES['gambar']['name'];
    
    if ($gambar != "") {
        // JIKA GANTI GAMBAR
        $tmp = $_FILES['gambar']['tmp_name'];
        $new_name = time() . '-' . $gambar;
        $path = "../uploads/" . $new_name;

        // Hapus gambar lama
        $data_lama = mysqli_fetch_assoc(mysqli_query($conn, "SELECT gambar FROM produk WHERE id = '$id'"));
        unlink("../uploads/" . $data_lama['gambar']);

        // Upload gambar baru
        move_uploaded_file($tmp, $path);

        // Update database dengan gambar baru
        $query = "UPDATE produk SET 
                  nama='$nama', model='$model', pressure='$pressure', 
                  capacity='$capacity', power='$power', deskripsi='$deskripsi', 
                  gambar='$new_name' WHERE id='$id'";
    } else {
        // JIKA TIDAK GANTI GAMBAR
        $query = "UPDATE produk SET 
                  nama='$nama', model='$model', pressure='$pressure', 
                  capacity='$capacity', power='$power', deskripsi='$deskripsi' 
                  WHERE id='$id'";
    }

    if(mysqli_query($conn, $query)){
        echo "<script>alert('Data Produk Berhasil Diupdate!'); window.location='produk.php?page=produk';</script>";
    } else {
        echo "<script>alert('Gagal Update Data!'); window.location='edit_produk.php?page=produk';</script>";
    }
}

// 4. HAPUS PRODUK
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT gambar FROM produk WHERE id = '$id'"));
    unlink("../uploads/" . $data['gambar']);
    mysqli_query($conn, "DELETE FROM produk WHERE id = '$id'");
    header("Location: produk.php?page=produk");
}

// ==========================================
// 5. LOGIKA TAMBAH ARTIKEL (UPDATE STRUKTUR BARU)
// ==========================================
if (isset($_POST['tambah_artikel'])) {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $rangkuman = mysqli_real_escape_string($conn, $_POST['rangkuman']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);
    $deskripsi_gambar = mysqli_real_escape_string($conn, $_POST['deskripsi_gambar']);
    $isi = mysqli_real_escape_string($conn, $_POST['isi']);
    $tanggal = date('Y-m-d'); // Tanggal hari ini
    $views = 0; // Default views 0

    $foto = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
    $newfoto = date('dmYHis').$foto;
    $path = "../uploads/".$newfoto;

    if (move_uploaded_file($tmp, $path)) {
        // Query disesuaikan dengan struktur tabel baru
        $query = mysqli_query($conn, "INSERT INTO artikel VALUES (NULL, '$judul', '$rangkuman', '$kategori', '$deskripsi_gambar', '$isi', '$newfoto', '$penulis', '$tanggal', '$views')");
        
        if ($query) {
            echo "<script>alert('Artikel Berhasil Dipublish'); window.location='artikel.php';</script>";
        } else {
            echo "<script>alert('Gagal Simpan Database: " . mysqli_error($conn) . "'); window.location='tambah_artikel.php';</script>";
        }
    } else {
        echo "<script>alert('Gagal Upload Gambar'); window.location='tambah_artikel.php';</script>";
    }
}

// ==========================================
// 6. LOGIKA UPDATE ARTIKEL (UPDATE STRUKTUR BARU)
// ==========================================
if (isset($_POST['update_artikel'])) {
    $id = $_POST['id'];
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $rangkuman = mysqli_real_escape_string($conn, $_POST['rangkuman']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);
    $deskripsi_gambar = mysqli_real_escape_string($conn, $_POST['deskripsi_gambar']);
    $isi = mysqli_real_escape_string($conn, $_POST['isi']);
    
    $foto = $_FILES['gambar']['name'];
    
    // Jika gambar diubah
    if ($foto != "") {
        $tmp = $_FILES['gambar']['tmp_name'];
        $newfoto = date('dmYHis').$foto;
        $path = "../uploads/".$newfoto;
        
        move_uploaded_file($tmp, $path);
        
        // Hapus gambar lama jika perlu (opsional)

        $query = mysqli_query($conn, "UPDATE artikel SET judul='$judul', rangkuman='$rangkuman', kategori='$kategori', penulis='$penulis', deskripsi_gambar='$deskripsi_gambar', isi='$isi', gambar='$newfoto' WHERE id='$id'");
    } else {
        // Jika gambar TIDAK diubah
        $query = mysqli_query($conn, "UPDATE artikel SET judul='$judul', rangkuman='$rangkuman', kategori='$kategori', penulis='$penulis', deskripsi_gambar='$deskripsi_gambar', isi='$isi' WHERE id='$id'");
    }

    if ($query) {
        echo "<script>alert('Artikel Berhasil Diupdate'); window.location='artikel.php';</script>";
    } else {
        echo "<script>alert('Gagal Update'); window.location='edit_artikel.php?id=$id';</script>";
    }
}
?>

<?php
session_start();
include '../db.php';

// Cek Login
if (!isset($_SESSION['admin'])) { 
    header("Location: login.php"); 
    exit(); 
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Produk - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* --- STYLE MODERN (SAMA DENGAN DASHBOARD & ARTIKEL) --- */
        :root {
            --sidebar-bg: #0a192f;
            --main-bg: #f0f2f5;
            --card-bg: #ffffff;
            --accent: #64ffda;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --danger: #ef4444;
            --warning: #f59e0b;
            --primary: #3b82f6;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--main-bg); display: flex; min-height: 100vh; overflow-x: hidden; }
        a { text-decoration: none; }

        /* SIDEBAR */
        .sidebar {
            width: 260px;
            background: var(--sidebar-bg);
            color: #fff;
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: 0.3s;
            box-shadow: 4px 0 20px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 40px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        
        .sidebar-header h3 { color: var(--accent); letter-spacing: 1px; margin-top: 10px; font-weight: 800; }

        .menu-container { padding: 20px 10px; }
        .menu-item {
            display: flex;
            padding: 15px 20px;
            color: #a8b2d1;
            transition: 0.3s;
            align-items: center;
            border-radius: 8px;
            margin-bottom: 5px;
            font-size: 0.95rem;
        }
        
        .menu-item:hover, .menu-item.active {
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent);
            transform: translateX(5px);
        }
        
        .menu-item i { width: 35px; font-size: 1.1rem; }

        /* MAIN CONTENT */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            padding: 30px;
        }

        /* TOP BAR */
        .top-bar {
            background: #fff;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h2 { color: var(--text-dark); font-size: 1.5rem; }

        /* CONTENT CARD */
        .card-box {
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03);
        }

        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .btn-add {
            background: var(--sidebar-bg);
            color: #fff;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: 0.3s;
            box-shadow: 0 4px 10px rgba(10, 25, 47, 0.2);
        }
        .btn-add:hover { background: #112240; transform: translateY(-2px); }

        /* TABLE STYLING */
        table { width: 100%; border-collapse: collapse; }
        thead { background: #f8fafc; }
        th { text-align: left; padding: 18px 15px; color: var(--text-light); font-size: 0.85rem; font-weight: 700; border-bottom: 1px solid #e2e8f0; }
        td { padding: 18px 15px; color: var(--text-dark); font-size: 0.9rem; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        tr:hover td { background: #f8fafc; }

        /* Product Specific Styles */
        .product-img {
            width: 70px;
            height: 70px;
            object-fit: cover; /* Biar gambar kotak rapi */
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: 1px solid #eee;
        }

        .badge-model {
            display: inline-block;
            background: #f1f5f9;
            color: var(--text-dark);
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-top: 5px;
            border: 1px solid #e2e8f0;
        }

        .spec-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.85rem;
            color: var(--text-light);
            margin-bottom: 4px;
        }
        .spec-item i { color: var(--primary); width: 15px; text-align: center; }

        /* Action Buttons */
        .action-btn {
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-right: 5px;
            transition: 0.3s;
        }
        .btn-edit { color: var(--warning); background: #fffbeb; border: 1px solid #fcd34d; }
        .btn-edit:hover { background: var(--warning); color: #fff; }
        
        .btn-del { color: var(--danger); background: #fef2f2; border: 1px solid #fecaca; }
        .btn-del:hover { background: var(--danger); color: #fff; }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar { width: 80px; text-align: center; }
            .sidebar h3, .menu-item span { display: none; }
            .main-content { margin-left: 80px; width: calc(100% - 80px); }
            .menu-item { justify-content: center; padding: 15px; }
            .menu-item i { margin: 0; width: auto; font-size: 1.5rem; }
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-fan fa-2x" style="color: #64ffda;"></i>
            <h3>ADMIN PANEL</h3>
        </div>
        <div class="menu-container">
            <a href="dashboard.php" class="menu-item"><i class="fas fa-th-large"></i> <span>Dashboard</span></a>
            
            <a href="produk.php" class="menu-item active"><i class="fas fa-wind"></i> <span>Data Root Blower</span></a>
            
            <a href="artikel.php" class="menu-item"><i class="fas fa-newspaper"></i> <span>Artikel & Berita</span></a>
            <a href="../index.php" target="_blank" class="menu-item"><i class="fas fa-globe"></i> <span>Lihat Website</span></a>
            <a href="logout.php" class="menu-item" style="color: #ff6b6b; margin-top: 50px;"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </div>

    <div class="main-content">
        
        <div class="top-bar">
            <div class="page-title">
                <h2>Kelola Data Produk</h2>
            </div>
            <div style="color: var(--text-light); font-size: 0.9rem;">
                <i class="far fa-calendar-alt"></i> <?php echo date('d F Y'); ?>
            </div>
        </div>

        <div class="card-box">
            <div class="header-actions">
                <div>
                    <h3 style="color:var(--text-dark); margin-bottom:5px;">Daftar Root Blower</h3>
                    <p style="color:var(--text-light); font-size:0.9rem;">Kelola unit, harga, dan spesifikasi di sini</p>
                </div>
                <a href="tambah_produk.php" class="btn-add">
                    <i class="fas fa-plus-circle"></i> Tambah Produk
                </a>
            </div>

            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th width="10%">Gambar</th>
                            <th width="30%">Nama Produk & Model</th>
                            <th width="45%">Spesifikasi Utama</th>
                            <th width="15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $q = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
                        
                        if(mysqli_num_rows($q) > 0){
                            while ($p = mysqli_fetch_assoc($q)) {
                        ?>
                        <tr>
                            <td>
                                <img src="../uploads/<?php echo $p['gambar']; ?>" class="product-img" alt="Produk">
                            </td>
                            
                            <td>
                                <div style="font-weight:700; color:var(--text-dark); font-size:1rem; margin-bottom:5px;">
                                    <?php echo $p['nama']; ?>
                                </div>
                                <?php if(!empty($p['model'])): ?>
                                    <div class="badge-model">
                                        <?php echo substr($p['model'], 0, 30) . (strlen($p['model']) > 30 ? '...' : ''); ?>
                                    </div>
                                <?php endif; ?>
                            </td>

                            <td>
                                <div class="spec-item">
                                    <i class="fas fa-tachometer-alt"></i> 
                                    <span><?php echo !empty($p['pressure']) ? $p['pressure'] : '-'; ?></span>
                                </div>
                                <div class="spec-item">
                                    <i class="fas fa-wind"></i> 
                                    <span><?php echo !empty($p['capacity']) ? $p['capacity'] : '-'; ?></span>
                                </div>
                                <div class="spec-item">
                                    <i class="fas fa-bolt"></i> 
                                    <span><?php echo !empty($p['power']) ? $p['power'] : '-'; ?></span>
                                </div>
                            </td>

                            <td>
                                <div style="display:flex;">
                                    <a href="edit_produk.php?id=<?php echo $p['id']; ?>" class="action-btn btn-edit" title="Edit Data">
                                        <i class="fas fa-pencil-alt"></i>
                                    </a>
                                    <a href="proses.php?hapus=<?php echo $p['id']; ?>" onclick="return confirm('Yakin hapus produk ini? Data yang dihapus tidak bisa dikembalikan.')" class="action-btn btn-del" title="Hapus Data">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php 
                            }
                        } else {
                            echo "<tr><td colspan='4' style='text-align:center; padding:40px; color:var(--text-light);'><i class='fas fa-box-open fa-2x' style='margin-bottom:10px;'></i><br>Belum ada data produk.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>
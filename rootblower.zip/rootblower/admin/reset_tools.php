<?php
include '../db.php';

$pesan = "";
$status = ""; // Untuk menentukan warna alert (sukses/gagal)

if (isset($_POST['reset'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password_baru = mysqli_real_escape_string($conn, $_POST['password_baru']);

    // Cek dulu apakah username ada?
    $cek_user = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
    
    if (mysqli_num_rows($cek_user) > 0) {
        // 1. Enkripsi password baru
        $password_hash = password_hash($password_baru, PASSWORD_DEFAULT);

        // 2. Update ke database
        $query = "UPDATE users SET password = '$password_hash' WHERE username = '$username'";
        mysqli_query($conn, $query);

        $status = "sukses";
        $pesan = "Password untuk user <b>$username</b> berhasil diubah!";
    } else {
        $status = "gagal";
        $pesan = "Username <b>$username</b> tidak ditemukan dalam database.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Reset Tools - PT Yuan Adam</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        /* --- RESET & BASIC STYLE --- */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }

        body {
            background-color: #0a192f; /* Dark Navy Background */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .tool-container {
            background: #ffffff;
            width: 100%;
            max-width: 450px;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.5);
            text-align: center;
            position: relative;
            overflow: hidden;
            border-top: 5px solid #ff6b6b; /* Warna Merah Warning */
        }

        .icon-header {
            font-size: 2.5rem;
            color: #ff6b6b;
            margin-bottom: 15px;
        }

        h2 { font-size: 1.6rem; color: #0a192f; margin-bottom: 5px; font-weight: 700; }
        
        .warning-text {
            background: #fff5f5;
            color: #c0392b;
            font-size: 0.85rem;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 25px;
            border: 1px dashed #ff6b6b;
        }

        /* --- FORM STYLE --- */
        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; margin-bottom: 8px; font-size: 0.9rem; font-weight: 600; color: #555; }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            background-color: #f9f9f9;
            transition: 0.3s;
        }

        .form-group input:focus {
            border-color: #0a192f;
            background-color: #fff;
            outline: none;
            box-shadow: 0 0 0 3px rgba(10, 25, 47, 0.1);
        }

        .btn-reset {
            width: 100%;
            padding: 12px;
            background-color: #0a192f;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 10px;
        }

        .btn-reset:hover {
            background-color: #ff6b6b; /* Berubah merah saat hover */
            transform: translateY(-2px);
        }

        .back-link {
            display: block;
            margin-top: 25px;
            font-size: 0.9rem;
            color: #888;
            text-decoration: none;
        }
        .back-link:hover { color: #0a192f; text-decoration: underline; }

        /* --- ALERT MESSAGES --- */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            text-align: left;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success { background-color: #d1fae5; color: #065f46; border: 1px solid #34d399; }
        .alert-error { background-color: #fee2e2; color: #991b1b; border: 1px solid #f87171; }
    </style>
</head>
<body>

    <div class="tool-container">
        <div class="icon-header">
            <i class="fas fa-tools"></i>
        </div>
        <h2>Admin Reset Tools</h2>
        
        <div class="warning-text">
            <i class="fas fa-exclamation-triangle"></i> Halaman Rahasia. Jangan bagikan link ini!
        </div>

        <?php if ($pesan != "") { ?>
            <div class="alert <?php echo ($status == 'sukses') ? 'alert-success' : 'alert-error'; ?>">
                <i class="fas <?php echo ($status == 'sukses') ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                <span><?php echo $pesan; ?></span>
            </div>
        <?php } ?>

        <form method="POST">
            <div class="form-group">
                <label>Username Target</label>
                <input type="text" name="username" placeholder="Masukkan username (misal: admin)" required autocomplete="off">
            </div>
            
            <div class="form-group">
                <label>Password Baru</label>
                <input type="text" name="password_baru" placeholder="Masukkan password baru" required autocomplete="off">
            </div>
            
            <button type="submit" name="reset" class="btn-reset">
                <i class="fas fa-key"></i> UBAH PASSWORD
            </button>
        </form>
        
        <a href="login.php" class="back-link">
            &larr; Kembali ke Halaman Login
        </a>
    </div>

</body>
</html>
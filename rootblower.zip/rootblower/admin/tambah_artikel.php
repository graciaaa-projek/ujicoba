<?php
session_start();
include '../db.php';

// Cek Login
if (!isset($_SESSION['admin'])) { 
    header("Location: login.php"); 
    exit(); 
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tulis Artikel - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* --- COPY STYLE MODERN DARI DASHBOARD --- */
        :root {
            --sidebar-bg: #0a192f;
            --main-bg: #f0f2f5;
            --card-bg: #ffffff;
            --accent: #64ffda;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --primary: #3b82f6;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--main-bg); display: flex; min-height: 100vh; overflow-x: hidden; }
        a { text-decoration: none; }

        /* SIDEBAR STYLE */
        .sidebar {
            width: 260px;
            background: var(--sidebar-bg);
            color: #fff;
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: 0.3s;
            box-shadow: 4px 0 20px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 40px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        
        .sidebar-header h3 { color: var(--accent); letter-spacing: 1px; margin-top: 10px; font-weight: 800; }

        .menu-container { padding: 20px 10px; }
        .menu-item {
            display: flex;
            padding: 15px 20px;
            color: #a8b2d1;
            transition: 0.3s;
            align-items: center;
            border-radius: 8px;
            margin-bottom: 5px;
            font-size: 0.95rem;
        }
        
        .menu-item:hover, .menu-item.active {
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent);
            transform: translateX(5px);
        }
        
        .menu-item i { width: 35px; font-size: 1.1rem; }

        /* MAIN CONTENT */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            padding: 30px;
        }

        /* TOP BAR */
        .top-bar {
            background: #fff;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h2 { color: var(--text-dark); font-size: 1.5rem; }

        /* FORM STYLE */
        .card-box {
            background: #fff;
            padding: 35px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03);
            max-width: 900px;
            margin: 0 auto;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
        }

        .card-header h3 { color: var(--text-dark); font-size: 1.2rem; }

        .btn-back {
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.9rem;
            transition: 0.3s;
        }
        .btn-back:hover { color: var(--sidebar-bg); }

        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-dark);
            font-size: 0.9rem;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            background: #f8fafc;
            color: var(--text-dark);
            font-family: inherit;
            transition: 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: #fff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        /* Grid Layout */
        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .btn-save {
            background: var(--sidebar-bg);
            color: #fff;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: 0.3s;
            margin-top: 10px;
        }
        .btn-save:hover {
            background: #112240;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(10, 25, 47, 0.2);
        }

        @media (max-width: 1024px) {
            .sidebar { width: 80px; text-align: center; }
            .sidebar h3, .menu-item span { display: none; }
            .main-content { margin-left: 80px; width: calc(100% - 80px); }
            .menu-item { justify-content: center; padding: 15px; }
            .menu-item i { margin: 0; width: auto; font-size: 1.5rem; }
            .grid-2 { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-fan fa-2x" style="color: #64ffda;"></i>
            <h3>ADMIN PANEL</h3>
        </div>
        <div class="menu-container">
            <a href="dashboard.php" class="menu-item"><i class="fas fa-th-large"></i> <span>Dashboard</span></a>
            <a href="produk.php" class="menu-item"><i class="fas fa-wind"></i> <span>Data Root Blower</span></a>
            
            <a href="artikel.php" class="menu-item active"><i class="fas fa-newspaper"></i> <span>Artikel & Berita</span></a>
            
            <a href="../index.php" target="_blank" class="menu-item"><i class="fas fa-globe"></i> <span>Lihat Website</span></a>
            <a href="logout.php" class="menu-item" style="color: #ff6b6b; margin-top: 50px;"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </div>

    <div class="main-content">
        
        <div class="top-bar">
            <div class="page-title">
                <h2>Tulis Artikel Baru</h2>
            </div>
            <div style="color: var(--text-light); font-size: 0.9rem;">
                <i class="far fa-calendar-alt"></i> <?php echo date('d F Y'); ?>
            </div>
        </div>

        <div class="card-box">
            <div class="card-header">
                <div>
                    <h3>Form Artikel</h3>
                    <p style="color: #888; font-size: 0.85rem;">Bagikan informasi, tips, atau berita terbaru.</p>
                </div>
                <a href="artikel.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
            
            <form action="proses.php" method="POST" enctype="multipart/form-data">
                
                <div class="form-group">
                    <label>Judul Artikel</label>
                    <input type="text" name="judul" class="form-control" placeholder="Contoh: Cara Merawat Root Blower Agar Awet" required>
                </div>

                <div class="grid-2">
                    <div class="form-group">
                        <label>Kategori</label>
                        <select name="kategori" class="form-control" required>
                            <option value="">-- Pilih Kategori --</option>
                            <option value="IPAL">IPAL (Instalasi Pengolahan Air Limbah)</option>
                            <option value="WWTP">WWTP (Wastewater Treatment Plant)</option>
                            <option value="WTP">WTP (Water Treatment Plant)</option>
                            <option value="STP">STP (Sewage Treatment Plant)</option>
                            <option value="Backwash">Backwash</option>
                            <option value="Tambak">Tambak Udang/Ikan</option>
                            <option value="Bioflok">Bioflok</option>
                            <option value="Aerasi">Sistem Aerasi</option>
                            <option value="Pneumatic">Pneumatic Conveying</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Penulis</label>
                        <input type="text" name="penulis" class="form-control" value="Admin" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Rangkuman Singkat (Excerpt)</label>
                    <textarea name="rangkuman" rows="3" class="form-control" placeholder="Tulis ringkasan pendek untuk tampilan depan (maks 200 karakter)..." required></textarea>
                </div>

                <div class="grid-2">
                    <div class="form-group">
                        <label>Upload Gambar Utama</label>
                        <input type="file" name="gambar" class="form-control" required accept="image/*" style="padding: 9px;">
                    </div>
                    <div class="form-group">
                        <label>Deskripsi Gambar (Alt Text)</label>
                        <input type="text" name="deskripsi_gambar" class="form-control" placeholder="Contoh: Teknisi sedang maintenance unit blower" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Isi Artikel Lengkap</label>
                    <textarea name="isi" rows="12" class="form-control" placeholder="Tulis isi konten lengkap di sini..." required></textarea>
                </div>
                
                <div style="text-align: right;">
                    <button type="submit" name="tambah_artikel" class="btn-save">
                        <i class="fas fa-paper-plane"></i> Publikasikan
                    </button>
                </div>

            </form>
        </div>
    </div>

</body>
</html>
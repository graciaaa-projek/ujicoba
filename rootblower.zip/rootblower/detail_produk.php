<?php 
include 'db.php'; 

// 1. Ambil ID dari URL
$id = $_GET['id'];

// 2. Query Data Produk Berdasarkan ID
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id = '$id'");
$data = mysqli_fetch_assoc($query);

// Kalau produk gak ada/dihapus, balikin ke index
if (!$data) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spesifikasi <?php echo $data['nama']; ?> - PT Yuan Adam</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* Kita pakai CSS yang sama dengan Trio Macan biar seragam */
        .brand-header {
            background: linear-gradient(rgba(10, 25, 47, 0.9), rgba(10, 25, 47, 0.8)), url('assets/img/bg.jpg');
            background-size: cover;
            background-position: center;
            padding: 100px 5%;
            text-align: center;
            color: white;
        }
        
        /* Copy style dari brand_anlet.php (Tech Showcase) */
        .product-overview { padding: 80px 5%; background: #fff; overflow: hidden; }
        .overview-wrapper { display: grid; grid-template-columns: 1.1fr 0.9fr; gap: 60px; max-width: 1200px; margin: 0 auto; align-items: center; }
        .overview-text h2 { font-size: 2.2rem; color: #0a192f; margin-bottom: 20px; position: relative; }
        .overview-text h2::after { content: ''; display: block; width: 80px; height: 4px; background: #64ffda; margin-top: 10px; }
        .overview-text p { color: #555; line-height: 1.8; margin-bottom: 20px; text-align: justify; }
        
        .tech-points { margin-top: 30px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .tp-item { display: flex; gap: 15px; align-items: flex-start; padding: 10px; border-radius: 8px; transition: 0.3s; }
        .tp-item:hover { background: #f0fdf4; }
        .tp-icon { background: #e0f2fe; color: #0a192f; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 8px; flex-shrink: 0; }
        .tp-desc h5 { font-size: 1rem; margin-bottom: 5px; color: #0a192f; font-weight: 700; }
        .tp-desc p { font-size: 0.85rem; line-height: 1.5; margin: 0; color: #666; }

        .overview-image { position: relative; padding: 20px; }
        .img-container { position: relative; z-index: 1; border-radius: 15px; overflow: hidden; box-shadow: 0 20px 40px rgba(10, 25, 47, 0.2); border: 2px solid white; }
        .img-container img { width: 100%; height: auto; display: block; }
        .floating-badge { position: absolute; bottom: 30px; right: -20px; background: #0a192f; color: #64ffda; padding: 15px 25px; border-radius: 10px; box-shadow: 0 10px 20px rgba(0,0,0,0.3); z-index: 2; display: flex; align-items: center; gap: 10px; border-left: 5px solid #64ffda; }

        /* Table Style */
        .catalog-section { padding: 80px 5%; background: #f8fafc; }
        .table-container { overflow-x: auto; background: white; padding: 0; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-top: 30px; border: 1px solid #eee; }
        table.spec-table { width: 100%; border-collapse: collapse; font-size: 0.9rem; color: #333; }
        table.spec-table thead { background-color: #0a192f; color: white; }
        table.spec-table th, table.spec-table td { padding: 18px 15px; text-align: center; border-bottom: 1px solid #eee; }
        table.spec-table td:first-child { text-align: left; font-weight: 700; color: #0a192f; padding-left: 20px; }
        
        .btn-wa-table { display: inline-block; background: #25D366; color: white; padding: 8px 15px; border-radius: 50px; font-size: 0.85rem; font-weight: 600; text-decoration: none; }

       @media (max-width: 900px) {
            /* Layout Utama jadi 1 kolom */
            .overview-wrapper { grid-template-columns: 1fr; gap: 40px; }
            
            /* Gambar pindah ke atas */
            .overview-image { order: -1; }
            
            /* Badge "Ready Stock" geser dikit */
            .floating-badge { right: 0; bottom: 20px; }

            /* --- INI OBATNYA BOS! --- */
            /* Paksa kotak fitur jadi 1 kolom ke bawah */
            .tech-points { 
                grid-template-columns: 1fr !important; 
                gap: 15px; /* Jarak antar kotak */
            }
            
            /* (Opsional) Biar isi kotaknya rapi menyamping di HP */
            .tp-item {
                flex-direction: row; /* Icon kiri, Teks kanan */
                align-items: center;
                padding: 15px;
            }
            
            .tp-icon {
                margin-right: 15px; /* Jarak icon ke teks */
                width: 50px;
                height: 50px;
            }
            
            .tp-desc p { font-size: 0.85rem; }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit; display:flex; align-items:center;">ROOTBLOWER<span>ID</span></a>
        </div>
        <div class="hamburger" onclick="toggleMenu()">
            <div class="bar"></div><div class="bar"></div><div class="bar"></div>
        </div>
        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link">Home</a>
            <div class="nav-link dropdown-parent">
                Tipe Root Blower <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="brand_anlet.php">ANLET</a>
                    <a href="brand_futsu.php">FUTSU</a>
                    <a href="brand_tsurumi.php">TSURUMI</a>
                </div>
            </div>
            <div class="nav-link dropdown-parent">
                Aplikasi <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="aplikasi_wwtp.php">WWTP / IPAL</a>
                    <a href="aplikasi_tambak.php">Tambak Udang</a>
                    <a href="aplikasi_aerasi.php">Aeration</a>
                    <a href="aplikasi_bioflok.php">Bioflok</a>
                </div>
            </div>
            <a href="harga.php" class="nav-link">Harga</a>
            <a href="about.php" class="nav-link">About Us</a>
            <a href="blog.php" class="nav-link">Artikel</a>
            <a href="https://wa.me/6289517227484?text=Halo%20Admin" target="_blank" class="btn-contact-mobile"><i class="fab fa-whatsapp"></i> Hubungi Kami</a>
        </div>
        <div class="nav-right">
            <a href="https://wa.me/6289517227484?text=Halo%20Admin" target="_blank" class="btn-contact"><i class="fab fa-whatsapp"></i> Hubungi Kami</a>
        </div>
    </nav>

    <header class="brand-header">
        <h1 style="font-size: 3rem; margin-bottom: 10px; text-transform: uppercase;"><?php echo $data['nama']; ?></h1>
        <p style="font-size: 1.2rem; color: #64ffda; font-weight: 600;">Specification Data Sheet</p>
    </header>

    <section class="product-overview">
        <div class="overview-wrapper">
            
            <div class="overview-text">
                <h2>Solusi Industri <span>Berkualitas Tinggi</span></h2>
                
                <p><?php echo nl2br($data['deskripsi']); ?></p>

                <div class="tech-points">
                    <div class="tp-item">
                        <div class="tp-icon"><i class="fas fa-certificate"></i></div>
                        <div class="tp-desc"><h5>Original Product</h5><p>Jaminan keaslian produk 100%.</p></div>
                    </div>
                    <div class="tp-item">
                        <div class="tp-icon"><i class="fas fa-tools"></i></div>
                        <div class="tp-desc"><h5>Technical Support</h5><p>Dukungan teknisi berpengalaman.</p></div>
                    </div>
                    <div class="tp-item">
                        <div class="tp-icon"><i class="fas fa-shipping-fast"></i></div>
                        <div class="tp-desc"><h5>Fast Delivery</h5><p>Pengiriman aman ke seluruh Indonesia.</p></div>
                    </div>
                    <div class="tp-item">
                        <div class="tp-icon"><i class="fas fa-headset"></i></div>
                        <div class="tp-desc"><h5>After Sales</h5><p>Layanan purna jual terjamin.</p></div>
                    </div>
                </div>
            </div>

            <div class="overview-image">
                <div class="img-container">
                    <img src="uploads/<?php echo $data['gambar']; ?>" alt="<?php echo $data['nama']; ?>">
                </div>
                <div class="floating-badge">
                    <i class="fas fa-check-circle"></i>
                    <div>
                        <span style="font-weight:800; font-size:0.9rem; color:#fff;">READY STOCK</span>
                        <span style="font-size:0.75rem; color:#64ffda;">Best Quality</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="catalog-section">
        <div class="section-title" style="text-align: center; margin-bottom: 40px;">
            <h2 style="font-size: 2.2rem; color: #0a192f;">Spesifikasi Teknis</h2>
            <p style="color:#666; margin-top:10px;">Detail performa unit <?php echo $data['nama']; ?></p>
        </div>

        <?php
        // --- LOGIKA PHP BUAT MECAH DATA (EXPLODE) ---
        
        // 1. Ambil data mentah dan pecah berdasarkan koma
        // Fungsi trim() buat ilangin spasi bandel di awal/akhir
        $models     = array_map('trim', explode(',', $data['model']));
        // Cek apakah kolom lain juga banyak isinya (array) atau cuma satu (string)
        // Kalau user input banyak data dipisah koma, kita pecah juga.
        // Kalau cuma satu data (misal pressure sama semua), kita duplikat biar jumlahnya sama kayak model.
        
        $count_data = count($models); // Hitung ada berapa model
        
        // Fungsi helper biar aman kalau datanya kosong
        function safe_explode($string, $count) {
            if (empty($string)) return array_fill(0, $count, '-');
            $arr = array_map('trim', explode(',', $string));
            // Kalau jumlah datanya kurang dari jumlah model, isi sisanya dengan data terakhir atau strip
            if (count($arr) < $count) {
                return array_pad($arr, $count, end($arr)); 
            }
            return $arr;
        }

        $pressures  = safe_explode($data['pressure'], $count_data);
        $capacities = safe_explode($data['capacity'], $count_data);
        $powers     = safe_explode($data['power'], $count_data);
        ?>

        <div class="table-container" style="max-width: 1200px; margin: 0 auto;">
            <table class="spec-table">
                <thead>
                    <tr>
                        <th style="width: 20%;">Model / Type</th>
                        <th style="width: 20%;">Pressure</th>
                        <th style="width: 25%;">Capacity</th>
                        <th style="width: 20%;">Power Motor</th>
                        <th style="width: 15%;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // LOOPING BARIS TABEL SEBANYAK JUMLAH MODEL
                    for ($i = 0; $i < $count_data; $i++) { 
                    ?>
                    <tr>
                        <td style="text-align: left; font-weight: 700; color: #0a192f; padding-left: 20px;">
                            <?php echo $models[$i]; ?>
                        </td>
                        <td>
                            <?php echo isset($pressures[$i]) ? $pressures[$i] : $pressures[0]; ?>
                        </td>
                        <td>
                            <?php echo isset($capacities[$i]) ? $capacities[$i] : $capacities[0]; ?>
                        </td>
                        <td>
                            <?php echo isset($powers[$i]) ? $powers[$i] : $powers[0]; ?>
                        </td>
                        <td>
                            <?php
                                $wa_text = "Halo Admin, saya minta penawaran harga untuk " . $data['nama'] . " Tipe " . $models[$i];
                            ?>
                            <a href="https://wa.me/6289517227484?text=<?php echo urlencode($wa_text); ?>" target="_blank" class="btn-wa-table" style="font-size: 0.8rem; padding: 8px 15px;">
                                <i class="fab fa-whatsapp"></i> Tanya Harga
                            </a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </section>

    <footer id="kontak">
        <div class="footer-content">
            
            <div class="footer-section">
                <h3>PT YUAN ADAM</h3>
                <p style="margin-bottom: 25px;">Distributor Root Blower terpercaya sejak 2026. Solusi tepat untuk pengolahan limbah dan aerasi industri.</p>

                <h4 style="color: #64ffda; margin-bottom: 15px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;">Follow Us</h4>
                <div class="social-links">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h3>Office</h3>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Head Office:</strong><br>
                    Jl. Basuki Rahmat No. 2 Batang - Jawa Tengah
                </div>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Semarang Office:</strong><br>
                    Jl. KS Tubun No.23 Ungaran Semarang - Jawa Tengah
                </div>
                <div>
                    <strong style="color: #fff;">Surabaya Office:</strong><br>
                    Ruko Galaxi Bumi Permai Blok J1/23A Jl. Raya Sukosemolo,  Semolowaru Sukolilo - Surabaya
                </div>
            </div>

            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Jl. Industri Raya No. 123, Indonesia</p>
                <p><i class="fas fa-phone"></i> +62 812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> admin@rootblower.id</p>
            </div>

        </div>
        
        <div class="copyright">
            <p>&copy; 2026 PT Yuan Adam. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Script Buka-Tutup Menu Panel
        function toggleMenu() {
            var menu = document.getElementById("navMenu");
            var hamburger = document.querySelector(".hamburger");
            menu.classList.toggle("active");
            hamburger.classList.toggle("active");
        }

        // --- TAMBAHAN BARU: SCRIPT DROPDOWN MOBILE --- //
        
        // Ambil semua elemen yang punya anak dropdown
        var dropdowns = document.querySelectorAll('.dropdown-parent');

        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(e) {
                // Cek apakah layar sedang mode HP (<= 991px)
                if (window.innerWidth <= 991) {
                    
                    // Kalau yang diklik bukan link di dalamnya (biar link anak tetep jalan)
                    if (e.target === this || e.target.tagName === 'I' || e.target.textContent.trim() === this.firstChild.textContent.trim()) {
                        
                        // Toggle class 'active' buat buka/tutup
                        this.classList.toggle('active');
                        
                        // Opsional: Tutup dropdown lain biar gak rame (Accordion effect)
                        dropdowns.forEach(function(other) {
                            if (other !== dropdown) {
                                other.classList.remove('active');
                            }
                        });
                    }
                }
            });
        });
    </script>
</body>
</html>
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spesifikasi Lengkap ANLET - PT Yuan Adam</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* --- BRAND HEADER --- */
        .brand-header {
            background: linear-gradient(rgba(10, 25, 47, 0.9), rgba(10, 25, 47, 0.8)), url('assets/img/bg.jpg');
            background-size: cover;
            background-position: center;
            padding: 100px 5%;
            text-align: center;
            color: white;
        }

        /* --- SECTION BARU: PRODUCT OVERVIEW (UPGRADED) --- */
        .product-overview {
            padding: 80px 5%;
            background: #fff;
            overflow: hidden; /* Biar hiasan gak keluar layar */
        }

        .overview-wrapper {
            display: grid;
            grid-template-columns: 1.1fr 0.9fr; /* Gambar lebih gede dikit */
            gap: 60px;
            max-width: 1200px;
            margin: 0 auto;
            align-items: center;
        }

        .overview-text h2 {
            font-size: 2.2rem;
            color: #0a192f;
            margin-bottom: 20px;
            line-height: 1.3;
            position: relative;
        }

        .overview-text h2::after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: #64ffda;
            margin-top: 10px;
            border-radius: 2px;
        }

        .overview-text h2 span { color: #64ffda; }

        .overview-text p {
            color: #555;
            line-height: 1.8;
            margin-bottom: 20px;
            text-align: justify;
            font-size: 1rem;
        }

        .tech-points {
            margin-top: 30px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .tp-item {
            display: flex;
            gap: 15px;
            align-items: flex-start;
            padding: 10px;
            border-radius: 8px;
            transition: 0.3s;
        }
        .tp-item:hover { background: #f0fdf4; }

        .tp-icon {
            background: #e0f2fe;
            color: #0a192f;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            flex-shrink: 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .tp-desc h5 { font-size: 1rem; margin-bottom: 5px; color: #0a192f; font-weight: 700; }
        .tp-desc p { font-size: 0.85rem; line-height: 1.5; margin: 0; color: #666; }

        /* --- IMAGE SHOWCASE YANG LEBIH KEREN --- */
        .overview-image {
            position: relative;
            padding: 20px;
        }

        /* Kotak Hiasan di Belakang Gambar */
        .overview-image::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 80%;
            height: 80%;
            background: #64ffda;
            opacity: 0.1;
            border-radius: 20px;
            z-index: 0;
        }

        .overview-image::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 150px;
            height: 150px;
            background-image: radial-gradient(#0a192f 2px, transparent 2px);
            background-size: 20px 20px;
            opacity: 0.2;
            z-index: 0;
        }

        .img-container {
            position: relative;
            z-index: 1;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(10, 25, 47, 0.2);
            border: 2px solid white;
        }

        .img-container img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.5s;
        }

        .img-container:hover img {
            transform: scale(1.05); /* Efek zoom dikit pas di-hover */
        }

        /* Floating Badge (Stiker Keren) */
        .floating-badge {
            position: absolute;
            bottom: 30px;
            right: -20px;
            background: #0a192f;
            color: #64ffda;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.3);
            z-index: 2;
            display: flex;
            align-items: center;
            gap: 10px;
            border-left: 5px solid #64ffda;
        }
        .floating-badge i { font-size: 1.5rem; }
        .floating-badge div { display: flex; flex-direction: column; }
        .fb-title { font-weight: 800; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; color: #fff; }
        .fb-sub { font-size: 0.75rem; color: #64ffda; }

        /* --- SECTION MENGAPA MEMILIH (Existing) --- */
        .brand-desc-section { padding: 80px 5%; background: #f8fafc; text-align: center; } 
        .brand-desc-section p { max-width: 800px; margin: 0 auto; font-size: 1.1rem; color: #555; line-height: 1.8; }

        .advantages-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; margin-top: 50px; }
        .adv-card { padding: 30px; background: #fff; border-radius: 10px; border-top: 4px solid #64ffda; text-align: left; transition: 0.3s; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .adv-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .adv-card h4 { color: #0a192f; margin-bottom: 10px; font-size: 1.2rem; }
        .adv-card p { font-size: 0.9rem; color: #666; }

        /* --- CSS TABEL DETAIL --- */
        .catalog-section { padding: 80px 5%; background: #fff; }
        
        .table-container {
            overflow-x: auto;
            background: white;
            padding: 0;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-top: 30px;
            border: 1px solid #eee;
        }

        table.spec-table { width: 100%; border-collapse: collapse; font-size: 0.9rem; color: #333; }
        table.spec-table thead { background-color: #0a192f; color: white; }
        table.spec-table th { padding: 18px 15px; text-align: center; font-weight: 600; letter-spacing: 0.5px; border-right: 1px solid rgba(255,255,255,0.1); }
        table.spec-table td { padding: 15px; border-bottom: 1px solid #eee; text-align: center; vertical-align: middle; }
        table.spec-table td:first-child { text-align: left; font-weight: 700; color: #0a192f; padding-left: 20px; }
        table.spec-table tr:hover { background-color: #f0fdf4; }

        .btn-wa-table {
            display: inline-block; background: #25D366; color: white; padding: 8px 15px; border-radius: 50px; font-size: 0.85rem; font-weight: 600; text-decoration: none; transition: 0.3s;
        }
        .btn-wa-table:hover { background: #1ebc57; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(37, 211, 102, 0.4); }

        /* Responsive */
        @media (max-width: 900px) {
            .overview-wrapper { grid-template-columns: 1fr; gap: 40px; }
            .overview-image { order: -1; margin-bottom: 10px; } 
            .floating-badge { right: 0; bottom: 20px; }
            .tech-points { grid-template-columns: 1fr; }
        }

    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit; display:flex; align-items:center;">
                ROOTBLOWER<span>ID</span>
            </a>
        </div>

        <div class="hamburger" onclick="toggleMenu()">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>

        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link">Home</a> 

            <div class="nav-link dropdown-parent">
                Tipe Root Blower <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="brand_anlet.php" class="nav-link active">ANLET</a>
                    <a href="brand_futsu.php">FUTSU</a>
                    <a href="brand_tsurumi.php">TSURUMI</a>
                </div>
            </div>

            <div class="nav-link dropdown-parent">
                Aplikasi <i class="fas fa-chevron-down"></i>
                <div class="dropdown-content">
                    <a href="aplikasi_wwtp.php">WWTP / IPAL</a>
                    <a href="aplikasi_tambak.php">Tambak Udang</a>
                    <a href="aplikasi_aerasi.php">Aeration</a>
                    <a href="aplikasi_bioflok.php">Bioflok</a>
                </div>
            </div>

            <a href="harga.php" class="nav-link">Harga</a>
            <a href="about.php" class="nav-link">About Us</a>
            <a href="blog.php" class="nav-link">Artikel</a>
            <a href="#kontak" class="btn-contact-mobile">Hubungi Kami</a>
        </div>

        <div class="nav-right">
            <a href="#kontak" class="btn-contact">Hubungi Kami</a>
        </div>
    </nav>

    <header class="brand-header">
        <h1 style="font-size: 3rem; margin-bottom: 10px;">ANLET ROOT BLOWER</h1>
        <p style="font-size: 1.2rem; color: #64ffda; font-weight: 600;">Specification Data Sheet</p>
    </header>

    <section class="product-overview">
        <div class="overview-wrapper">
            <div class="overview-text">
                <h2>Teknologi Jepang untuk <span>Efisiensi Maksimal</span></h2>
                <p>
                    <strong>ANLET Co., Ltd.</strong> adalah pionir teknologi root blower asal Jepang yang telah beroperasi lebih dari 70 tahun. Produk ANLET dikenal di seluruh dunia karena inovasi <strong>Rotor 3-Lobes</strong> yang revolusioner, menggantikan desain 2-lobes tradisional yang berisik dan boros energi.
                </p>
                <p>
                    Root Blower ANLET tipe BSS/BO Series dirancang khusus untuk menghasilkan udara bebas oli (oil-free) yang bersih, menjadikannya pilihan utama untuk industri sensitif seperti aerasi tambak, pengolahan air limbah (WWTP), dan pneumatic conveying. Desain casing "Endless" yang unik membantu menghemat energi secara signifikan dibandingkan kompetitor sekelasnya.
                </p>

                <div class="tech-points">
                    <div class="tp-item">
                        <div class="tp-icon"><i class="fas fa-fan"></i></div>
                        <div class="tp-desc">
                            <h5>3-Lobe Rotor Design</h5>
                            <p>Mengurangi pulsasi tekanan balik, aliran udara stabil & minim getaran.</p>
                        </div>
                    </div>
                    <div class="tp-item">
                        <div class="tp-icon"><i class="fas fa-leaf"></i></div>
                        <div class="tp-desc">
                            <h5>Energy Saving</h5>
                            <p>Struktur casing unik mencegah kebocoran udara internal.</p>
                        </div>
                    </div>
                    <div class="tp-item">
                        <div class="tp-icon"><i class="fas fa-tint-slash"></i></div>
                        <div class="tp-desc">
                            <h5>Oil-Free Operation</h5>
                            <p>Ruang kompresi terpisah dari gear oil, udara 100% murni.</p>
                        </div>
                    </div>
                    <div class="tp-item">
                        <div class="tp-icon"><i class="fas fa-cogs"></i></div>
                        <div class="tp-desc">
                            <h5>Easy Maintenance</h5>
                            <p>Bearing tipe khusus yang tahan lama dan mudah diganti.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="overview-image">
                <div class="img-container">
                    <img src="assets/img/anlet.jpg" alt="ANLET Root Blower Unit">
                </div>
                
                <div class="floating-badge">
                    <i class="fas fa-certificate"></i>
                    <div>
                        <span class="fb-title">100% ORIGINAL</span>
                        <span class="fb-sub">Made in Japan</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="brand-desc-section">
        <h2 style="color: #0a192f; margin-bottom: 20px;">Mengapa Memilih ANLET?</h2>
        <p>
            Anlet Co., Ltd. adalah produsen root blower terkemuka dari Jepang yang dikenal dengan presisi tinggi. 
            Berikut adalah detail spesifikasi teknis untuk setiap tipe unit yang tersedia.
        </p>

        <div class="advantages-grid">
            <div class="adv-card">
                <i class="fas fa-volume-mute fa-2x" style="color: #0a192f; margin-bottom: 15px;"></i>
                <h4>Low Noise</h4>
                <p>Suara mesin sangat halus, cocok untuk lingkungan rumah sakit atau apartemen.</p>
            </div>
            <div class="adv-card">
                <i class="fas fa-bolt fa-2x" style="color: #0a192f; margin-bottom: 15px;"></i>
                <h4>High Efficiency</h4>
                <p>Konsumsi daya rendah dengan output udara maksimal.</p>
            </div>
            <div class="adv-card">
                <i class="fas fa-tools fa-2x" style="color: #0a192f; margin-bottom: 15px;"></i>
                <h4>Long Life</h4>
                <p>Durabilitas tinggi standar industri Jepang.</p>
            </div>
        </div>
    </section>

    <section class="catalog-section" id="katalog-anlet">
        <div class="section-title">
            <h2>Tabel Spesifikasi Teknis ANLET Type BO</h2>
            <p style="color:#666; margin-top:10px;">Data performa detail berdasarkan ukuran pipa discharge (Outlet)</p>
        </div>

        <?php
        // ARRAY DATA MANUAL
        $data_anlet = [
            ['tipe' => 'ANLET BO-50', 'outlet' => '2" (50mm)', 'power' => '0.75 - 2.2 kW', 'pressure' => '10 - 60 kPa', 'capacity' => '0.83 - 1.54 m³/min'],
            ['tipe' => 'ANLET BO-65', 'outlet' => '2.5" (65mm)', 'power' => '1.5 - 3.7 kW', 'pressure' => '10 - 60 kPa', 'capacity' => '1.45 - 2.66 m³/min'],
            ['tipe' => 'ANLET BO-80', 'outlet' => '3" (80mm)', 'power' => '2.2 - 5.5 kW', 'pressure' => '10 - 60 kPa', 'capacity' => '2.41 - 4.13 m³/min'],
            ['tipe' => 'ANLET BO-100', 'outlet' => '4" (100mm)', 'power' => '3.7 - 11 kW', 'pressure' => '10 - 60 kPa', 'capacity' => '4.23 - 7.55 m³/min'],
            ['tipe' => 'ANLET BO-125', 'outlet' => '5" (125mm)', 'power' => '7.5 - 18.5 kW', 'pressure' => '10 - 60 kPa', 'capacity' => '7.15 - 12.3 m³/min'],
            ['tipe' => 'ANLET BO-150', 'outlet' => '6" (150mm)', 'power' => '11 - 30 kW', 'pressure' => '10 - 60 kPa', 'capacity' => '11.5 - 22.8 m³/min'],
            ['tipe' => 'ANLET BO-200', 'outlet' => '8" (200mm)', 'power' => '18.5 - 45 kW', 'pressure' => '10 - 60 kPa', 'capacity' => '21.5 - 45.9 m³/min']
        ];
        ?>

        <div class="table-container">
            <table class="spec-table">
                <thead>
                    <tr>
                        <th style="width: 25%;">Model / Type</th>
                        <th style="width: 15%;">Outlet (Inch)</th>
                        <th style="width: 20%;">Pressure (kPa)</th>
                        <th style="width: 20%;">Capacity (m³/min)</th>
                        <th style="width: 20%;">Power Motor</th>
                        <th style="width: 15%;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($data_anlet as $item): ?>
                    <tr>
                        <td>
                            <?php echo $item['tipe']; ?>
                            <div style="font-size:0.8rem; color:#888; font-weight:400;">Series Japan</div>
                        </td>
                        <td><strong><?php echo $item['outlet']; ?></strong></td>
                        <td><?php echo $item['pressure']; ?></td>
                        <td><?php echo $item['capacity']; ?></td>
                        <td><?php echo $item['power']; ?></td>
                        <td>
                            <a href="https://wa.me/6289517227484?text=Halo%20Admin,%20saya%20minta%20penawaran%20harga%20untuk%20<?php echo urlencode($item['tipe']); ?>" target="_blank" class="btn-wa-table">
                                <i class="fab fa-whatsapp"></i> Tanya Harga
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>

    <footer id="kontak">
        <div class="footer-content">
            
            <div class="footer-section">
                <h3>PT YUAN ADAM</h3>
                <p style="margin-bottom: 25px;">Distributor Root Blower terpercaya sejak 2026. Solusi tepat untuk pengolahan limbah dan aerasi industri.</p>

                <h4 style="color: #64ffda; margin-bottom: 15px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;">Follow Us</h4>
                <div class="social-links">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h3>Office</h3>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Head Office:</strong><br>
                    Jl. Basuki Rahmat No. 2 Batang - Jawa Tengah
                </div>
                <div style="margin-bottom: 15px;">
                    <strong style="color: #fff;">Semarang Office:</strong><br>
                    Jl. KS Tubun No.23 Ungaran Semarang - Jawa Tengah
                </div>
                <div>
                    <strong style="color: #fff;">Surabaya Office:</strong><br>
                    Ruko Galaxi Bumi Permai Blok J1/23A Jl. Raya Sukosemolo,  Semolowaru Sukolilo - Surabaya
                </div>
            </div>

            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Jl. Industri Raya No. 123, Indonesia</p>
                <p><i class="fas fa-phone"></i> +62 812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> admin@rootblower.id</p>
            </div>

        </div>
        
        <div class="copyright">
            <p>&copy; 2026 PT Yuan Adam. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Script Buka-Tutup Menu Panel
        function toggleMenu() {
            var menu = document.getElementById("navMenu");
            var hamburger = document.querySelector(".hamburger");
            menu.classList.toggle("active");
            hamburger.classList.toggle("active");
        }

        // --- TAMBAHAN BARU: SCRIPT DROPDOWN MOBILE --- //
        
        // Ambil semua elemen yang punya anak dropdown
        var dropdowns = document.querySelectorAll('.dropdown-parent');

        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(e) {
                // Cek apakah layar sedang mode HP (<= 991px)
                if (window.innerWidth <= 991) {
                    
                    // Kalau yang diklik bukan link di dalamnya (biar link anak tetep jalan)
                    if (e.target === this || e.target.tagName === 'I' || e.target.textContent.trim() === this.firstChild.textContent.trim()) {
                        
                        // Toggle class 'active' buat buka/tutup
                        this.classList.toggle('active');
                        
                        // Opsional: Tutup dropdown lain biar gak rame (Accordion effect)
                        dropdowns.forEach(function(other) {
                            if (other !== dropdown) {
                                other.classList.remove('active');
                            }
                        });
                    }
                }
            });
        });
    </script>

</body>
</html>